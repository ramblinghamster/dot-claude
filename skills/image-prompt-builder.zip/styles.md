# Style Library
## Image Prompt Builder — Saved Styles

This file stores your personal named styles. Each style is pre-translated for both ChatGPT
(DALL-E 3) and Niji Journey so it can be applied directly to any prompt without re-describing.

To add a new style, copy any entry below and fill in your own values.
To invoke a style during a session, say its name (e.g., "use Kurosawa" or "apply Neon Noir").

---

## How Styles Are Applied

When a style is loaded, its values override or enrich the following blocks:
- **Block 5 (Lighting):** if the style specifies a lighting approach
- **Block 6 (Style, Medium & Art Direction):** primary style language
- **Block 7 (Mood, Color Palette & Texture):** mood, palette, and texture descriptors

The user can still override any element after the style loads.

---

## STYLE: Sumi-e
**Aliases:** sumi-e, ink wash, sumi, brush ink
**Best for:** character portraits, fantasy creatures, landscapes, any subject where ink brush texture and tonal drama are the point
**Conflicts with:** clean digital linework, flat cel shading, vivid color palettes, glossy rendering

### Visual Description
Traditional Japanese ink wash rendering on textured paper. Black ink tones only — no color.
Form is built through brush pressure variation: bold confident strokes for structure, soft
bleeding washes for shadow and atmosphere. Edges are organic and imperfect — ink bleeds into
paper naturally. White paper serves as light. Tonal range from pure black to pale grey wash.
Paper texture (washi or similar) is always visible. Anime character proportions rendered
through brush technique rather than pen linework.

### Style Negatives
color, clean digital linework, flat cel shading, sharp uniform edges, glossy rendering, gradient backgrounds, photorealistic rendering, chibi proportions, neon lighting

### ChatGPT Translation
```
Traditional sumi-e ink wash anime illustration on textured paper — all form built through
brush pressure variation, bold confident ink strokes for structure, soft bleeding washes for
shadow and volume, organic imperfect edges where ink bleeds into paper, black ink tones only
with full tonal range from pure black to pale grey wash, white paper as light source, visible
paper texture throughout. Drawn as a traditional ink wash illustration — 2D anime proportions,
no color, no digital linework, no sharp uniform edges.
```

### Niji Journey Translation
```
traditional sumi-e ink wash anime illustration, black ink tones, brush strokes, soft bleeding edges, textured paper, tonal shading
```

---

## STYLE: Pencil Sketch
**Aliases:** pencil sketch, pencil drawing, graphite, graphite sketch, pencil art
**Best for:** character portraits, OC showcases, detailed costume studies, fan art, any subject where a monochrome hand-drawn graphite feel is the point
**Conflicts with:** color, clean digital linework, flat cel shading, glossy rendering, painterly styles

### Visual Description
Monochrome graphite pencil drawing on paper. Smooth tonal gradients built through pencil
pressure — soft shading for skin and fabric, denser strokes for shadows and hard edges.
Line quality mixes sharp precise lines for structural detail with softer, looser strokes
for hair and cloth. Visible pencil grain throughout. Grey-scale only — no color. Paper
texture shows through, especially in lighter areas. The paper itself can be plain white
or ruled notebook paper with faint lines visible beneath the drawing.

### Style Negatives
color, clean digital linework, flat cel shading, ink outlines, glossy rendering, gradient backgrounds, painterly blending, airbrush smoothness, photorealistic rendering, neon lighting, chibi proportions

### ChatGPT Translation
```
Traditional graphite pencil anime illustration on paper — smooth tonal gradients built through
pencil pressure variation, mixed sharp and soft line quality, visible pencil grain throughout,
grey-scale only with full tonal range from dark graphite to faint sketch lines, paper texture
visible especially in light areas, denser strokes for shadows and structural edges, softer
looser strokes for hair and fabric. Drawn entirely as a graphite pencil sketch on paper — 2D
anime proportions, no color, no ink outlines, no digital rendering, no airbrush smoothness.
```

### Niji Journey Translation
```
traditional graphite pencil anime sketch, pencil drawing on paper, grey-scale, smooth tonal shading, visible pencil grain, mixed sharp and soft lines, paper texture
--ar [ratio]
```

---

## STYLE: Crewdson
**Aliases:** crewdson, staged, suburban surreal, staged cinema
**Best for:** interior scenes, portraiture, emotionally loaded stillness, suburban or coastal settings
**Conflicts with:** action scenes, fantasy environments, bright comedic tone

### Visual Description
Large-format staged photography aesthetic — images that feel like stills from a film that
doesn't exist. Hyper-real yet constructed, every element in the frame deliberately placed
as though by a set designer. Single dominant light source, often from a window or doorway,
casting raking shadows. Desaturated midtones with warm amber highlights and deep teal
shadows. The subject is always in the middle of something private, emotionally ambiguous,
and slightly melancholic. No direct eye contact.

### Style Negatives
action scenes, bright cheerful palette, fantasy environments, comedic tone, flat cel shading, chibi proportions, clean minimal backgrounds, direct eye contact, energetic poses, saturated vivid colors

### ChatGPT Translation
```
Cinematic large-format staged aesthetic, anime illustration — theatrically composed,
hyper-detailed, every element deliberately placed as though by a set designer, still from
a film that does not exist. Desaturated midtones with rich amber highlights and deep teal
shadows, single raking light source from a window or doorway, long dramatic shadows, quiet
constructed melancholy, emotionally ambiguous narrative, no direct eye contact, 2D anime
art style.
```

### Niji Journey Translation
```
soft painterly anime illustration, staged cinematic composition, warm amber and deep teal palette, single window light, long shadows
```

---

## STYLE: Neon Noir
**Aliases:** neon noir, cyberpunk noir, neon, rain noir
**Best for:** urban night scenes, cyberpunk, mystery/thriller mood, futuristic dystopia
**Conflicts with:** daylight scenes, pastoral environments, warm cheerful palettes

### Visual Description
Rain-slicked streets reflecting neon signage. Deep shadows punctuated by electric magenta,
cyan, and amber. Smoke or steam rising from vents. The city feels alive but predatory.
Figures are silhouetted or partially lit, never fully revealed. High contrast between deep
blacks and intense color. The visual language of cyberpunk noir and hardboiled detective fiction.

### Style Negatives
daylight scenes, pastoral environments, warm cheerful palette, pastel colors, flat cel shading, soft ambient lighting, clean minimal aesthetic, cute or whimsical tone, chibi proportions

### Usage Notes
- **For anime rendering:** Neon Noir alone pulls toward photorealistic/live-action feel.
  To render in anime style, stack Hyperreal Anime as the base rendering layer and apply
  Neon Noir conditions on top. Anchor with descriptors like `semi-realistic 2D anime`,
  `clean anime linework`, `cyberpunk anime aesthetic` to lock the rendering language.
- **Stacking:** Lead prompt with Hyperreal Anime rendering language, then add Neon Noir
  atmosphere conditions (neon color palette, wet reflections, anamorphic flare, etc.).

### ChatGPT Translation
```
Neon noir anime illustration — rain-slicked urban streets reflecting electric neon light in
magenta, cyan, and amber, deep shadow contrast, smoke and steam rising from vents, cinematic
wide shot, figures silhouetted or half-lit, cyberpunk noir atmosphere, mysterious and predatory
mood, wet surface reflections, anamorphic lens flare, desaturated except for neon color pops,
clean anime linework, 2D anime art style.
```

### Niji Journey Translation
```
neon noir anime, electric magenta and cyan neon reflections, deep shadows, clean anime linework, high contrast
```

---

## STYLE: Editorial Fashion
**Aliases:** editorial, fashion editorial, vogue, high fashion, magazine
**Best for:** product shots, portraiture, luxury goods, high-end commercial imagery
**Conflicts with:** rustic/organic environments, heavy texture, fantasy or sci-fi themes

### Visual Description
Clean, controlled, and intentional. Minimal props. Precise directional lighting — a large
softbox, natural window light, or raking golden-hour sun — that creates crisp highlights and
soft, controlled shadow. Color palette follows the mood of the shoot rather than a single
fixed temperature: desaturated and cool with lifted blacks for a clinical, minimalist look, or
warm and sun-drenched (amber, terracotta, golden light) for a lifestyle-luxury look. Either
reads as editorial as long as it stays restrained and intentional rather than candy-bright or
garish. The subject commands the frame. Negative space is used deliberately. Feels like a
luxury fashion magazine or high-end commercial spread — elevated, restrained, and aspirational.

### Style Negatives
rustic organic environments, heavy texture, fantasy or sci-fi elements, cluttered composition, oversaturated candy-bright palette, painterly rendering, chibi proportions, hand-drawn roughness, busy detailed backgrounds

### ChatGPT Translation
```
High-end editorial fashion anime illustration — clean and minimal composition, precise
directional lighting (softbox or golden-hour sun), crisp highlights with soft controlled
shadow falloff, restrained color palette (cool desaturated or warm sun-drenched, matching
the scene's mood) with lifted blacks, generous negative space, aspirational and restrained
mood, luxury fashion editorial quality, ultra high detail, 2D anime art style.
```

### Niji Journey Translation
```
editorial fashion anime illustration, minimal composition, soft directional lighting, restrained cool or warm palette, crisp highlights, negative space
```

---

## STYLE: Studio Ghibli
**Aliases:** ghibli, miyazaki, studio ghibli, ghibli style
**Best for:** nature scenes, childhood wonder, fantasy worlds, quiet emotional moments
**Conflicts with:** dark horror, gritty realism, cyberpunk, hyperrealistic photography

### Visual Description
Warm, painterly, and richly detailed environments that feel handcrafted. Soft natural
lighting — dappled sunlight through leaves, golden afternoon, misty mornings. Nature is
lush and alive. Characters have expressive round features. The mood is wistful, wonder-filled,
and emotionally gentle. Colors are saturated but never harsh — warm greens, soft blues,
golden yellows, deep earth tones.

### Style Negatives
photorealistic, dark horror, gritty realism, cyberpunk neon, hyperrealistic rendering, sharp digital linework, desaturated palette, heavy shadows, dramatic contrast, cold clinical lighting, action poses, violent content

### ChatGPT Translation
```
Studio Ghibli-inspired aesthetic — warm, painterly illustration with handcrafted texture,
soft dappled natural lighting, lush detailed environments, wistful and wonder-filled mood,
emotionally gentle atmosphere, rich saturated warm greens and golden yellows, expressive
character design, classic Japanese anime film visual language.
```

### Niji Journey Translation
```
Studio Ghibli style, soft painterly illustration, warm dappled natural lighting, rich saturated warm palette, handcrafted texture
```

---

## STYLE: Dark Fantasy
**Aliases:** dark fantasy, grimdark, gothic fantasy, dark epic
**Best for:** fantasy characters, creatures, ominous landscapes, epic world-building
**Conflicts with:** cheerful or pastel palettes, comedic tone, minimal clean aesthetics

### Visual Description
Brooding, epic, and atmospheric. Deep jewel tones — emerald, crimson, obsidian — against
near-black backgrounds. Dramatic rim or volumetric lighting. Heavy use of fog, smoke, or
falling ash. Architectural elements are gothic or ancient — crumbling stone, iron, bone.
Characters feel mythic in scale. The world has weight and danger. Grand, threatening, and
mythic — the visual language of dark fantasy concept art at its most epic.

### Style Negatives
cheerful pastel palette, comedic tone, flat cel shading, clean minimal aesthetic, bright daylight, cute proportions, chibi, slice-of-life settings, soft ambient lighting

### ChatGPT Translation
```
Dark fantasy anime illustration — brooding and atmospheric, deep jewel tones of emerald and
crimson against near-black backgrounds, dramatic volumetric rim lighting, heavy fog and smoke,
gothic architectural ruins, crumbling stone and iron, mythic character scale, dangerous and
ancient world, oppressive gothic visual weight, painterly cinematic anime art style, expressive anime linework.
```

### Niji Journey Translation
```
dark fantasy anime illustration, deep jewel tones emerald crimson obsidian, volumetric rim lighting, heavy fog, gothic atmosphere, expressive anime linework
```

---

## STYLE: Ember
**Aliases:** ember, warm matte, lantern glow, tavern glow, matte anime
**Best for:** dark fantasy interiors, tavern/inn scenes, candlelit portraits, visual novel characters, anime with warmth and intimacy
**Conflicts with:** cold/clinical palettes, bright daylight scenes, hyperrealistic photography, cyberpunk neon

### Visual Description
Semi-painterly anime rendering with a matte finish and soft diffuse shading. The signature
element is warm amber light — gentle rim lighting, luminous lantern or candlelight glow —
set against a dark fantasy environment that feels inviting rather than threatening. Soft cel
shading with thin elegant lineart, hand-painted texture, and subtle bloom on light sources.
Faces are softly illuminated, shadows are balanced rather than harsh, and the overall
atmosphere is smoky, rich, and intimate. Feels like a high-quality visual novel illustration
or a cinematic anime still.

### Style Negatives
cold clinical palette, bright daylight, flat cel shading, neon cyberpunk lighting, hyperrealistic rendering, outdoor scenes, desaturated monochrome, harsh high-contrast shadows, action poses

### ChatGPT Translation
```
Semi-painterly anime aesthetic with a matte finish, soft diffuse shading, and cinematic warm
lighting. Gentle amber rim light and luminous lantern glow cast softly illuminated faces
against rich, smoky shadows. Hand-painted anime texture with thin elegant linework, subtle
bloom on light sources, balanced shadows, and warm midtones. Dark fantasy setting with
inviting warmth and tavern ambience — visual novel illustration quality, painterly depth.
```

### Niji Journey Translation
```
semi-painterly anime, matte finish, soft diffuse shading, amber rim light, lantern glow, thin elegant lineart, warm midtones, subtle bloom
```

---

## STYLE: Prism
**Aliases:** prism, crystal light, caustic light, refraction, spectral dispersion, glass light, realistic crystal
**Best for:** characters near or holding refractive objects (glass, crystal, potion bottles, lenses, prisms), product and jewelry close-ups, window-light scenes, any scene where physically accurate light behavior through glass or crystal is the point
**Conflicts with:** holographic/glitter fantasy aesthetics, Neon Noir, dark moody realism without a clear light source, Kurosawa, Crewdson

### Visual Description
A physically accurate light and refraction aesthetic where a real refractive object — a glass
bottle, crystal, prism, lens, or gemstone — is the single source of all light scatter in the
scene. The rendering base is semi-realistic anime (clean linework, smooth gradients, no
painterly texture), but the lighting behavior is governed by optics: white light enters the
object and splits into spectral color bands on exit, caustics — sharp irregular pools of
spectrum color — are projected onto nearby skin, fabric, and surfaces. Chromatic aberration
separates red and violet at the edges of refracted beams. Nothing glows on its own. There is
one coherent light source; the object bends and casts it.

The background is dark or neutral so caustic projections read with maximum clarity. The
palette outside the light effects is restrained — the spectral colors are the only saturation
in the frame. The mood is precise, luminous, and quietly scientific: beautiful because the
physics is beautiful, not because glitter was added. No holographic shimmer, no floating
particles, no ambient neon scatter.

### Style Negatives
holographic shimmer, glitter, neon glow, ambient shimmer, floating particles, sparkles, oversaturated colors, fantasy scatter, lens flare blooms, multiple light sources, painterly texture, rough linework, flat cel shading

### ChatGPT Translation
```
Semi-realistic 2D anime illustration, clean precise anime linework, smooth digital rendering —
physically accurate refraction and caustics lighting. A single refractive object (glass bottle,
crystal prism, gemstone, or lens) is the sole source of light scatter in the scene. Sharp
caustic light projections cast onto skin and fabric from the object only, spectral dispersion
splitting white light into spectrum color bands, chromatic aberration separating red and violet
at refracted beam edges. Dark or neutral background so caustic patterns read clearly. Restrained
palette — spectral refraction colors are the only saturation. No holographic shimmer, no glitter,
no ambient glow, no floating particles. Precise luminous optical realism, anime illustration style.
```

### Niji Journey Translation
```
semi-realistic anime, clean linework, smooth rendering, light refraction caustics, spectral dispersion, chromatic aberration, dark neutral background, restrained palette
--ar 2:3
```

---

## STYLE: Aquarelle
**Aliases:** aquarelle, watercolor anime, soft wash, washi, analog anime, quiet anime, gouache
**Best for:** original character portraits, full-body illustrations, emotionally subtle scenes, understated fantasy, slice-of-life, travel or nature themes
**Conflicts with:** Prism, Neon Noir, Dark Fantasy, dramatic cinematic lighting, glossy/polished aesthetics, sci-fi or magical effects

### Visual Description
A genuine analog watercolor aesthetic where the medium leads and the anime character
design sits loosely within it. The base is a visible pencil or ink underdrawing —
slightly scratchy, imprecise, showing through beneath the color. Watercolor washes
are applied sparsely and unevenly over the sketch, barely contained within outlines,
with large areas of white paper left intentionally unpainted within the hair, clothing,
and body. Nothing is fully rendered. Figures dissolve and fade at the edges, clothing
fades out below the waist into unfinished linework, and the background is almost
entirely absent — raw paper texture with faint color pooling at most.

The palette is near-greyscale: whispers of warm tan, soft grey-blue, and pale peach
that barely read as color. Saturation is suppressed throughout. The overall impression
is a beautiful sketchbook page rather than a finished illustration — intimate,
restrained, and emotionally present through what is left unpainted as much as what
is painted. High quality expressed through incompleteness, not complexity.

### Style Negatives
clean vector lineart, full rendering, detailed background, glossy plastic texture, oversaturated colors, harsh contrast, excessive decoration, dense rendering, dramatic cinematic lighting, magical effects, sci-fi elements, digital smoothness, gacha polish

### ChatGPT Translation
```
Genuine watercolor and ink sketch anime illustration — loose visible pencil and ink
linework underneath soft sparse watercolor washes, large areas of white paper left
intentionally unpainted within the figures, color barely contained within outlines,
washes applied unevenly and incompletely. Figures dissolve and fade at the edges,
clothing and bodies fading into unfinished sketch below. Almost no background —
raw paper texture only with faint color pooling at edges. Near-greyscale palette:
only whispers of warm tan, soft grey-blue, and pale peach, never saturated. Loose
scratchy analog linework, visible brush strokes, intentional incompleteness, quiet
intimate mood. A beautiful sketchbook page, not a finished illustration. No clean
vector lines, no full rendering, no detailed background, 2D anime sketch style.
```

### Niji Journey Translation
```
watercolor ink sketch anime, visible pencil linework under sparse washes, white paper areas unpainted, near-greyscale palette warm tan soft grey-blue, loose scratchy linework, sketchbook aesthetic
--ar 2:3
```

---

## STYLE: Ironbloom
**Aliases:** ironbloom, iron bloom, tactical anime, arms girl, gear girl, mech contrast, tactical ink, mil-moe, military manga, ink mecha, hard ink, mech sketch
**Best for:** characters with complex armor, mechanical suits, military/tactical gear, fantasy plate armor, sci-fi equipment, steampunk machinery — any scene contrasting a soft anime character with hard technical detail. Fantasy, sci-fi, military, steampunk, post-apocalyptic, pilot portraits all work.
**Conflicts with:** Aquarelle, Studio Ghibli, soft painterly styles, lush detailed backgrounds, warm intimate interiors

### Visual Description
The defining tension of this style is a soft anime character face and fragile human presence set against hyper-detailed, technically precise mechanical or structural complexity — armor, gear, weapons, equipment, machinery. The contrast between delicate and formidable is always the point. Both sub-moods render against a white or near-white negative space background that isolates the subject.

### Style Negatives
lush detailed backgrounds, painterly atmospheric rendering, soft warm interiors, pastel palettes, cute aesthetic, chibi proportions, flat cel shading without detail contrast, glossy smooth digital finish

**Rendered sub-mood:** Semi-flat cel shading with visible rendering depth. Earth and neutral tones (sand, khaki, olive, dark brown). Equipment rendered with technical-illustration precision — every buckle, panel, joint, and surface detail present and readable. Often carries a thematic juxtaposition: something delicate (a flower, a small creature, a gentle gesture) against something formidable.

**Flat/Ink sub-mood:** Flat manga ink linework. Each armor panel has a large flat interior with clean color fill and no hatching or crosshatch shading. Wear is sparse and surgical — a few strategic grime dots or scratch lines only. Line economy over density. Negative space preserved aggressively within the armor, around the subject, and in the background. Result feels light and airy despite mechanical complexity. Palette is fully user-defined — not locked to earth tones.

### Usage Notes
- Ask which sub-mood if context doesn't make it clear
- Rendered sub-mood: earth tones default, more rendering depth, thematic delicacy contrast
- Flat/Ink sub-mood: palette-agnostic, flat fills, line economy — lighter and more graphic

### ChatGPT Translation

**Rendered sub-mood:**
```
Clean bold manga lineart with semi-flat shading and hyper-detailed technical rendering of
complex armor or equipment. Muted earth tone palette of sand, khaki, olive, and dark brown
against a white or near-white negative space background. Soft expressive anime character
face contrasted with precisely rendered mechanical or structural complexity — every panel,
joint, and surface detail present. Emotionally resonant thematic contrast between something
formidable and something delicate. Technical illustration precision, manga quality, 2D anime
art style.
```

**Flat/Ink sub-mood:**
```
2D manga illustration, flat clean ink linework, anime character with soft expressive face —
mechanically complex armor and tactical hardware rendered with structural precision: clean
panel seam lines, joint assemblies, bolt and cable detail, large flat color fills inside each
armor panel with no hatching or texture, sparse intentional wear limited to a few strategic
grime dots and scratch marks, strong contrast between soft anime face and hard mechanical
structure, generous negative space preserved throughout including within the armor, minimal or
white background, line economy over density, light airy feel despite mechanical complexity,
[user-defined palette], professional manga illustration quality.
```

### Niji Journey Translation

**Rendered sub-mood:**
```
bold manga lineart, hyper-detailed armor, semi-flat shading, muted earth tones, white background, soft anime face with hard mechanical contrast
```

**Flat/Ink sub-mood:**
```
flat manga ink linework, soft anime face, flat color fills no hatching, sparse wear marks, white background, line economy, [user-defined palette]
--ar [ratio]
```

---

## STYLE: Makoto Shinkai
**Aliases:** makoto shinkai, shinkai, luminous sky, shinkai sky, atmospheric sky anime
**Best for:** emotional outdoor scenes, dramatic skies, distance and longing, cityscapes at golden hour, two characters separated by space or light
**Conflicts with:** interior-only scenes, Kurosawa monochrome, flat design, hard toon cel shading

### Visual Description
Luminous atmospheric anime illustration with hyper-detailed painterly backgrounds — layered
clouds, drifting rain, and dramatic volumetric light rays that feel almost tactile. Colors are
intensely saturated but natural: deep blues, warm ambers, electric golds. Backgrounds carry
near-photographic density while characters retain clean 2D anime linework, creating a rich
painterly contrast. Emotional register is quiet reflection and distance — light falling across
a face, rain streaking a window, the space between two people rendered as vividly as the
people themselves.

### Style Negatives
interior-only scenes, monochrome palette, flat cel shading, hard toon outlines, chibi proportions, minimal backgrounds, dark enclosed spaces, desaturated colors

### ChatGPT Translation
```
Luminous atmospheric anime illustration with hyper-detailed painterly backgrounds, dramatic
volumetric light rays, layered rain, intensely saturated natural blues and warm amber light,
cinematic composition, emotional sense of distance and quiet reflection, clean 2D anime
character linework contrasted against richly painted environments.
```

### Niji Journey Translation
```
luminous atmospheric anime style, hyper-detailed painterly backgrounds, volumetric light rays, layered rain, saturated deep blue amber gold palette, clean 2D anime character linework, cinematic emotional distance
```

---

## STYLE: Ufotable
**Aliases:** ufotable, ufotable dark fantasy, dark fantasy action anime, supernatural anime spectacle
**Best for:** action sequences, dark fantasy combat, supernatural scenes, dramatic character moments, high-production anime key visuals
**Conflicts with:** Aquarelle, Kurosawa monochrome, flat design, retro anime

### Visual Description
The signature visual language of Ufotable animation studio — high-production dark fantasy
anime at its most cinematic. High-contrast dramatic lighting with richly saturated jewel-toned
colors: deep crimson, electric blue, vivid gold against near-black shadows. Cinematic polish
with fluid motion energy even in still images. Characters are rendered with meticulous detail
and glowing intensity — effects like fire, water, and supernatural energy are rendered as
breathtaking visual spectacles. The overall feel is expensive, dramatic, and technically
flawless. Dark settings are elevated by explosive color rather than muted.

### Style Negatives
flat cel shading, retro analog grain, watercolor texture, monochrome palette, minimal backgrounds, chibi proportions, soft ambient lighting, muted desaturated colors, hand-drawn roughness

### ChatGPT Translation
```
Ufotable animation studio aesthetic — high-contrast dramatic lighting, richly saturated jewel
tones of deep crimson, electric blue, and vivid gold against near-black shadows, cinematic
production polish, meticulous character detail with glowing intensity, supernatural energy
effects rendered as visual spectacle, fluid motion energy, expensive and technically flawless
dark fantasy anime quality, premium high-production anime visual language.
```

### Niji Journey Translation
```
Ufotable studio style, high contrast dramatic lighting, saturated jewel tones crimson blue gold, near-black shadows, cinematic anime polish, glowing energy effects
```

---

## STYLE: Retro Anime
**Aliases:** retro anime, 80s anime, 90s anime, vhs anime, old school anime, analog anime, retro sci-fi anime
**Best for:** nostalgic scenes, action and drama, urban or sci-fi settings, character-driven moments, any scene benefiting from analog warmth and grain
**Conflicts with:** Prism, Ufotable, clean modern anime aesthetics, hyperrealistic rendering

### Visual Description
The visual language of 1980s–90s anime — cel-animated sci-fi action, urban drama, space
opera, and fantasy adventure from that era. Analog warmth with visible film grain and subtle
color bleed at edges. Linework is slightly thicker and less precise than modern anime, with a
hand-drawn quality that feels intentional and characterful. Color palette has a distinctive
muted warmth — faded yellows, dusty blues, warm oranges — as if slightly sun-bleached or
viewed through a VHS lens. Cel animation textures, limited color banding, and the occasional
halftone dot pattern. Emotionally direct and kinetic. Crucially, background and surface detail
is limited to what genuine vintage cel animation production would allow — flat gouache-style
color blocks, broad simple shapes, and minimal texture complexity. Modern AI tendency to add
fine grain, intricate surface texture, or high-frequency detail is antithetical to this style.

### Style Negatives
clean modern digital linework, hyperrealistic rendering, smooth gradients, fine surface texture, photographic grain, high-frequency detail, complex material rendering, intricate background texture, modern digital detail levels

### ChatGPT Translation
```
Retro 1980s–90s anime aesthetic — analog film grain, subtle VHS color bleed at edges,
slightly thick hand-drawn linework, muted warm palette of faded yellows, dusty blues, and
warm oranges, cel animation texture, limited color banding, emotionally direct and kinetic
energy, classic retro anime visual language, nostalgic analog warmth, hand-crafted
imperfection over digital polish. Authentic hand-painted cel animation production art — flat
broad color fills with minimal texture detail, limited cel layers, backgrounds painted in flat
gouache-style blocks with low detail complexity, simple clean shapes over intricate surface
detail, color limited to what a 1980s anime production budget would allow. No fine surface
texture, no photographic grain, no high-frequency detail, no complex material rendering, no
modern digital detail levels, no intricate background texture.
```

### Niji Journey Translation
```
retro 80s 90s anime, analog film grain, thick hand-drawn linework, muted warm palette faded yellows dusty blues, cel animation texture, flat broad color fills, simple clean shapes
```

---

## STYLE: Cel Shading
**Aliases:** cel shading, cel shaded, bold outline, graphic anime, toon shading, comic shading, graphic toon
**Best for:** action scenes, graphic novels, high-energy characters, poster compositions, any scene where bold graphic impact matters more than realism
**Conflicts with:** Aquarelle, Crewdson, Makoto Shinkai, any painterly or atmospheric style

### Visual Description
Bold black outlines, flat color fills, and high-contrast shading with no gradients — the
visual language of toon-shaded action games, comic books, and graphic novel illustration.
Colors are vivid and fully saturated. Shading is binary: lit or shadow, with a hard edge
between them. Linework is thick, confident, and expressive. The overall effect is graphic,
energetic, and immediately readable. Depth comes from composition and color contrast rather
than rendering subtlety. Feels designed to be seen from a distance and understood instantly.

### Style Negatives
gradients, painterly rendering, soft atmospheric shading, watercolor texture, photorealistic rendering, subtle shadow transitions, muted desaturated palette, thin invisible outlines

### ChatGPT Translation
```
2D anime cel shading illustration — bold black outlines, flat fully-saturated color fills,
high-contrast binary shading with hard edges between light and shadow, no gradients,
thick confident expressive linework, vivid color palette, graphic novel and toon-shaded
game visual language, energetic and immediately readable, depth through composition and color
contrast rather than rendering subtlety.
```

### Niji Journey Translation
```
anime cel shading, bold black outlines, flat color fills, no gradients, thick expressive linework, vivid saturated colors, toon shading
```

---

## STYLE: Soulslike
**Aliases:** soulslike, souls aesthetic, gothic horror fantasy, gothic action rpg, ruin aesthetic
**Best for:** gothic architecture, horror fantasy, fog-shrouded landscapes, cursed or corrupted characters, bleak and grand environments, ancient decaying worlds
**Conflicts with:** Ember, Ghibli, Makoto Shinkai, warm or inviting aesthetics

### Visual Description
The visual language of gothic action RPG concept art — a desaturated, fog-heavy gothic
aesthetic where grandeur and dread occupy the same space. Color palette is predominantly
grey, ash, and muted teal with isolated accents of deep amber or bloodred. Architecture
is massive, decaying, and inhuman in scale. Characters are dwarfed by their environments.
Fog, ash particles, and atmospheric haze obscure backgrounds, creating mystery and weight.
Unlike Dark Fantasy (which uses jewel tones and epic warmth), Soulslike is bleaker, quieter,
and more unsettling — beauty that comes from ruin.

### Style Negatives
warm inviting palette, bright saturated colors, cute aesthetic, chibi proportions, cheerful mood, clean minimal backgrounds, flat cel shading, comedic tone, pastoral or nature scenes

### ChatGPT Translation
```
Gothic action RPG soulslike anime illustration — desaturated gothic atmosphere in grey, ash, and
muted teal with isolated accents of deep amber or bloodred, massive decaying architecture
that dwarfs human scale, fog and ash particles obscuring the background, a pervasive sense
of ancient ruin and quiet dread, grandeur and horror coexisting, bleaker and more unsettling
than traditional dark fantasy, gothic horror RPG concept art aesthetic, 2D anime art style, detailed anime linework.
```

### Niji Journey Translation
```
soulslike gothic anime, desaturated grey ash muted teal, deep amber accents, massive decaying architecture, atmospheric fog and ash, detailed anime linework
```

---

## STYLE: Miura
**Aliases:** miura, dark manga, crosshatch, crosshatch manga, dense ink manga
**Best for:** intense character portraits, brutal battle scenes, dark fantasy figures, deeply detailed armor and weapons, monochromatic or limited-color dramatic compositions
**Conflicts with:** Ghibli, Aquarelle, Ember, soft or colorful styles

### Visual Description
The aesthetic of peak-craft dark fantasy manga — one of the most technically demanding
illustration styles ever produced. Dense, precise crosshatching builds shadow and texture in
ways that feel almost engraved. Linework is extraordinarily detailed, with heavy blacks that
create dramatic contrast. Armor, weapons, and environmental detail are rendered with obsessive
specificity — every rivet, scratch, and surface texture accounted for. Figures feel massive
and heavy. The overall aesthetic is monochromatic or near-monochromatic, with shadow doing
the emotional and atmospheric work. Brutal, meticulous, and awe-inspiring.

### Style Negatives
soft colorful palette, flat cel shading, clean digital linework, cute aesthetic, chibi proportions, watercolor texture, pastel colors, minimal linework, cheerful mood, simplified detail

### ChatGPT Translation
```
Peak-craft dark fantasy manga aesthetic — dense precise crosshatching building shadow and
texture with engraving-like depth, extraordinarily detailed linework, heavy blacks creating
dramatic contrast, obsessively detailed armor and weapons with every rivet and scratch
rendered, massive and heavy figure weight, monochromatic or near-monochromatic palette with
shadow doing the emotional work, brutal meticulous and awe-inspiring dark manga quality.
```

### Niji Journey Translation
```
dark fantasy manga, dense crosshatching, heavy black ink shadows, extraordinarily detailed linework, near-monochromatic, massive figure weight
```

---

## STYLE: JRPG Pixel Art
**Aliases:** jrpg pixel art, pixel art, pixel sprite, hd pixel, jrpg sprite, modern pixel art, hd-2d pixel
**Best for:** fantasy characters with detailed equipment, knight and warrior sprites, character portrait sprites, any subject that benefits from the contrast between pixel grid constraints and rich anime-influenced design
**Conflicts with:** painterly or atmospheric styles, Aquarelle, Crewdson, Makoto Shinkai, any style relying on smooth lineart or gradients

### Visual Description
High-resolution modern pixel art with an anime-influenced character aesthetic — not chunky
16x16 retro pixel work, but a detailed fine-grid approach where every pixel is intentional
and expressive. Character proportions and facial features follow anime conventions: large
expressive eyes, styled flowing hair with visible pixel curl and movement, soft round face.
Equipment and armor are rendered with rich full-color pixel shading using careful dithering
and color stepping to simulate volume and metallic sheen. The palette is full-color rather
than limited, with warm skin tones, deep jewel accents, and clean neutrals. Background is
near-white or absent, isolating the character as a standalone sprite. Sits closest to modern
JRPG sprite work — HD-2D fine-grid pixel RPG art, high-end mobile RPG character art, or premium gacha
game sprites.

### Style Negatives
smooth gradients, soft anti-aliased edges, vector linework, painterly rendering, atmospheric lighting, watercolor texture, photorealistic rendering, smooth digital finish

### ChatGPT Translation
```
Pixel art sprite with visible square pixels — every element built from a discrete pixel grid,
NO smooth gradients, NO soft anti-aliased edges, NO vector linework. Style reference: Octopath
Traveler HD-2D sprite, Tactics Ogre Reborn unit sprite, Final Fantasy Tactics character artwork.
Anime-influenced character design rendered entirely in pixel form: large expressive eyes drawn
from individual pixel clusters, flowing styled hair built from stepped pixel color bands, detailed
fantasy armor with full-color pixel shading and manual dithering to simulate metallic volume and
jewel-toned accents. Warm skin tones, near-white or transparent background isolating her as a
standalone sprite. The pixel grid must be visible — this is a pixelated image, not an
illustration of pixel art.
```

### Niji Journey Translation
```
JRPG pixel art sprite, visible pixel grid, Octopath Traveler HD-2D style, dithered shading, full color palette, pixelated not smooth
--ar 2:3
```

### Usage Notes
- **DALL-E 3 drift warning:** DALL-E consistently interprets "pixel art aesthetic" as smooth anime illustration. The ChatGPT translation above uses hard constraints ("visible square pixels", "NO smooth gradients", game references) to fight this — always use the full translation, never paraphrase.
- If DALL-E still ignores pixels: prepend "Pixelated game sprite in the style of Octopath Traveler —" to the subject description.
- Niji Journey produces cleaner pixel results than DALL-E for this style.

---

## STYLE: Shounen Burst
**Aliases:** shounen burst, shounen, modern shounen, action anime, railgun, supernatural action, warm action
**Best for:** characters with supernatural abilities, school or urban settings mid-destruction, power awakening moments, action scenes where the contrast between a warm decaying world and cold or sharp supernatural force is the emotional anchor
**Conflicts with:** Soulslike, Kurosawa, Crewdson, Aquarelle, any style requiring restraint or quiet atmosphere

### Visual Description
A modern digital anime style where a warm, aged-paper world collides with cold or sharp
supernatural force. Backgrounds and environments are pushed into warm sepia and cream tones —
walls, floors, and debris feel sun-bleached or faded, almost like the world itself is old
paper. Against this warm decay, the character's power cuts through as something cold, sharp,
or sudden. The specific effect can take any form — electric arcs, shadow tendrils, wind
pressure waves, ice, void energy, or pure kinetic force — as long as it reads as *cold,
sharp, or sudden* against the warm environmental decay. The contrast between the warm world
and the cold power is the point, not the specific ability. Character rendering is clean and
precise with fuller, more saturated color than the environment. Environments feature high
detail — rubble, cracked surfaces, scattered debris — with strong volumetric backlit window
light. The character is always mid-motion but composed: determined, not frantic.

### Style Negatives
quiet restrained atmosphere, monochrome palette, flat cel shading, watercolor texture, static poses, soft ambient lighting, pastel cheerful mood, minimal backgrounds

### ChatGPT Translation
```
Modern shounen action anime aesthetic — warm sepia-toned environment rendered like aged paper
(cream, yellow-brown, dusty warm gray) contrasted with a crisp cold or sharp supernatural
effect (electric arcs, shadow energy, wind pressure, void force, or kinetic impact — anything
that reads as sudden and cold against warm decay), high-detail environmental destruction
(rubble, cracked surfaces, scattered debris), clean precise character rendering with clean anime linework, fuller
color against the warm environmental chaos, strong volumetric backlit window light creating
haze and silhouette contrast, character mid-action but composed and determined.
```

### Niji Journey Translation
```
modern shounen anime, warm sepia tones, cold sharp supernatural energy contrast, environmental destruction debris, clean anime linework, volumetric backlit light
--ar 2:3
```

---

## STYLE: Moe Gacha
**Aliases:** moe gacha, gacha mascot, sd mascot, chibi mascot, plush mascot, vinyl figure mascot, mascot chibi, gacha keychain
**Best for:** premium mascot-style character art rather than action chibi — vinyl figure and acrylic stand illustrations, collectible keychain designs, gacha promotional key art, mascot icon art. Any character concept works; the constant is extreme super-deformed proportions and toy-like presentation, not a theme.
**Conflicts with:** Miura, Soulslike, Kurosawa, Dark Fantasy — realistic anatomy or gritty rendering; Flat Chibi, Daily Chibi — related but distinct chibi approaches (see comparisons in style-guide.md)

### Visual Description
Modern Moe Gacha mascot illustration built on extreme super-deformed (SD) proportions —
more extreme than traditional action chibi. The oversized head occupies roughly 65-75% of
the character's total height, paired with an extremely small plush-like body, tiny stubby
limbs, oversized mitten-like hands and feet, and simplified anatomy. Silhouettes are rounded
and soft, prioritizing toy-like appeal over dynamic energy or realistic proportion. Line art
is clean, confident, and medium-thick, tapering subtly at the ends, with minimal interior
line clutter so shapes stay highly readable even at small sizes. Shading is soft cel work
using only 2-3 broad shadow values blended with subtle airbrushed gradients — enough to
suggest volume without turning painterly. Materials read smooth and stylized with almost no
visible texture; gentle bloom surrounds emissive elements and soft rim lighting separates the
figure from its background. Large glossy eyes dominate the face alongside a tiny nose and
small mouth, with graphic, exaggerated expressions rather than anatomically grounded ones.
Hair simplifies into large flowing clumps with minimal strand detail. The palette pairs
saturated accent colors against soft neutral bases for a luminous, collectible-feeling
result rather than physically realistic lighting. Clothing folds, armor panel lines, and
props are reduced to large clean shapes, with visual interest carried by color design and
silhouette rather than intricate rendering. Poses are still and presentational rather than
dynamic — a single confident stance or gesture, not mid-action. Closest to premium mobile
gacha promotional art, vinyl figure and acrylic stand illustration, and high-end mascot key
art.

### Style Negatives
realistic anatomy, normal human proportions, elongated limbs, mature body proportions, painterly rendering, photorealism, excessive texture, highly detailed muscles, intricate clothing folds, realistic lighting, cinematic realism, complex mechanical detail, tiny head, semi-realistic face, dynamic action pose, gritty atmosphere

### ChatGPT Translation
```
Modern Moe Gacha mascot illustration with extreme super-deformed proportions — the oversized
head occupies roughly 70% of the character's total height, paired with a tiny plush-like
body, tiny stubby limbs, and oversized mitten-like hands and feet. Rounded silhouettes, soft
curves, and toy-like appeal throughout, in a still, presentational pose rather than dynamic
action. Clean confident digital line art with medium-thick tapered outlines and minimal
interior line clutter, keeping every shape highly readable. Soft cel shading uses only 2-3
broad shadow values blended with subtle airbrushed gradients for gentle volume, smooth
stylized surfaces with almost no visible texture, gentle bloom around emissive elements, and
soft colored rim lighting separating the figure from the background. Large glossy anime eyes
with a tiny nose and small mouth carry an exaggerated, graphic cute expression; hair is
simplified into large soft flowing clumps with minimal strand detail. Saturated accent colors
against a soft neutral base give a luminous, collectible appearance. Premium mobile gacha
promotional art quality, like a collectible vinyl figure or acrylic stand illustration,
polished mascot character design, 2D anime illustration style.
```

### Niji Journey Translation
```
extreme SD mascot proportions, oversized head tiny plush body, stubby limbs, mitten hands and feet, soft cel shading airbrushed gradients, clean tapered linework, glossy anime eyes, still presentational pose, premium gacha mascot art
--no realistic anatomy, elongated limbs, dynamic action pose, heavy texture, painterly rendering
--ar 1:1
```

---

## STYLE: Webtoon
**Aliases:** webtoon, manhwa, korean webtoon, line webtoon, manhwa art, korean manhwa
**Best for:** dramatic character moments, fashion-forward character designs, urban fantasy, action sequences, romance and slice-of-life, any scene that benefits from crisp clean linework and strong character presence
**Conflicts with:** Kurosawa, Aquarelle, Crewdson, painterly or atmospheric styles, anything requiring analog texture or heavy environmental mood

### Visual Description
The clean, high-polish aesthetic of Korean webtoon and manhwa — premium manhwa action and
romance visual language. Linework is crisp and confident with consistent weight, slightly
rounder and more fashion-forward than Japanese manga. Shading is smooth and controlled, often
cel-style with soft gradient accents on hair and skin. Characters are the undisputed focal
point — faces expressive, hair rendered with precision and volume, clothing detailed and
fashion-conscious. Color is saturated but clean; palettes are deliberate rather than
atmospheric. Backgrounds are either high-detail and architectural or minimal, depending on
the scene. The overall feel is polished, modern, and cinematic — built for scrolling vertical
presentation but striking in any format.

### Style Negatives
analog texture, heavy environmental mood, painterly rendering, watercolor washes, film grain, rough hand-drawn linework, monochrome palette, atmospheric haze

### ChatGPT Translation
```
Korean webtoon and manhwa aesthetic — crisp confident linework with consistent line weight,
smooth cel shading with soft gradient accents on hair and skin, fashion-forward character
design with expressive faces and precisely rendered hair volume, saturated clean color
palette, characters as the primary focal point against either high-detail architectural
backgrounds or minimal clean settings, polished cinematic production quality, premium Korean webtoon
and manhwa visual language.
```

### Niji Journey Translation
```
Korean webtoon manhwa style, crisp clean linework, smooth cel shading soft gradients, fashion-forward character design, saturated clean palette
--ar 9:16
```

---

## STYLE: Storybook
**Aliases:** storybook, children's book, picture book, gouache illustration, storybook illustration, fairy tale art
**Best for:** fairy tale scenes, animal characters, young protagonists, whimsical fantasy, nature and forest settings, any scene that should feel warm, safe, and wonder-filled
**Conflicts with:** dark or violent themes, Soulslike, Miura, Neon Noir, any style requiring dramatic tension or adult emotional weight

### Visual Description
The warm, handcrafted aesthetic of classic illustrated children's books — gouache or
watercolor washes over ink linework, with soft rounded shapes and an inviting color palette
of warm ochres, sage greens, dusty roses, and cream. Compositions are clear and readable,
with subjects front and center and environments rendered as simplified but characterful
backdrops. Texture is visible — paper grain, brush marks, the slight irregularity of
hand-applied media. Characters have round, expressive features with large eyes and simplified
anatomy. The mood is wonder, safety, and gentle whimsy — the world is slightly magical but
never threatening. Closest to Maurice Sendak, Beatrix Potter, or the picture book style of
a Studio Ghibli storyboard.

### Style Negatives
dark violent themes, dramatic tension, adult emotional weight, sharp digital linework, hyperrealistic rendering, neon lighting, desaturated palette, complex detailed backgrounds, action poses

### ChatGPT Translation
```
Anime storybook illustration — soft warm painterly anime rendering with a gouache-like
digital finish, rounded anime characters with large expressive eyes and soft simplified
silhouettes, warm inviting color palette of ochres, sage greens, dusty roses, and cream,
gentle brush texture and soft color washes, whimsical fairy tale environments with clearly
readable illustrated backgrounds, mood of wonder, safety, and gentle warmth, Japanese anime
picture book and Ghibli artbook visual language.
```

### Niji Journey Translation
```
anime storybook illustration, gouache-like painting, rounded characters large eyes, warm palette ochre sage green dusty rose, gentle brush texture, simplified backgrounds
--ar 4:3
```

---

## STYLE: Storybook Impasto
**Aliases:** storybook impasto, heavy gouache, textured gouache, impasto picture book, thick paint storybook, dry-brush storybook
**Best for:** fairy tale scenes, animal companions, whimsical fantasy, nature settings, any scene that should feel tactile, handcrafted, and warmly painted rather than digitally smooth
**Conflicts with:** dark or violent themes, Soulslike, Miura, Neon Noir, any style requiring dramatic tension or adult emotional weight; also conflicts with glossy/sharp-rendering styles like Prism, Cinematic Anime, and Hyperreal Anime, since impasto texture works against polished surface sheen

### Visual Description
A heavier, more physically tactile variant of Storybook. Where Storybook uses soft gouache
washes, Storybook Impasto leans into thick, opaque paint applied with visible, confident
brushstrokes — dry-brush streaks, ridges of built-up pigment, and the tooth of the painting
paper showing through thinner passages. Color is laid down in flat, simplified blocks rather
than fine gradients; fur, foliage, and fabric are suggested through brushwork rather than
rendered in detail. Characters retain Storybook's round, expressive features and warm
palette of ochres, sage greens, dusty roses, and cream, but surfaces avoid any glossy,
glassy, or digitally smooth finish — even reflective materials like crystal or metal are
rendered as flat matte facets of color. Lighting stays soft and even, without dramatic rim
light or cinematic highlights, keeping the focus on the handmade, textured quality of the
paint itself.

### Style Negatives
glossy digital finish, glassy shine, smooth digital rendering, dramatic rim light, cinematic highlights, sharp precise linework, photorealistic texture, fine detail rendering, polished surface sheen, clean vector lines

### ChatGPT Translation
```
Anime storybook illustration, painted entirely in a thick, opaque gouache style with heavy visible brushwork. Every surface carries the chalky, matte texture of hand-applied gouache pigment — soft, slightly uneven brushstroke edges, visible dry-brush streaks, and the gentle tooth of painting paper showing through thin areas of color. Subjects are rendered in flat, simplified color blocks with thick, confident brushstrokes and visible ridges of dried paint rather than fine detail, fur strands, or digital smoothness. Even reflective or crystalline materials are painted as flat matte facets with no glossy or glassy shine. Lighting is soft and even, with no dramatic rim light or cinematic highlights. Rounded, simplified silhouettes in a warm palette of ochres, sage greens, dusty roses, and cream evoke the tactile, handcrafted feel of a classic illustrated picture book page — fully gouache-painted, with no digital sheen or cinematic rendering.
```

### Niji Journey Translation
```
anime storybook illustration, thick gouache texture, heavy visible brushstrokes, flat matte color blocks, rounded characters large eyes, warm palette ochre sage green dusty rose, hand-painted look
--no glossy shine, digital smoothness, rim light, cinematic highlights
--ar 4:3
```

---

## ADD YOUR OWN STYLE

## STYLE: Gacha Splash
**Aliases:** gacha splash, anime splash, key visual, gacha art, vtuber art, jrpg splash, anime key visual, gacha key visual
**Best for:** high-energy character moments, fantasy RPG characters, VTuber key visuals, spell casting and power moments, dynamic poses with motion, any scene that needs premium cinematic gacha production quality
**Conflicts with:** Kurosawa, Crewdson, Miura — anything restrained, dark, or static in a grounded way; this style is inherently energetic and polished

### Visual Description
The premium action splash art aesthetic of high-end gacha games, JRPG key visuals, and
VTuber promotional art. Semi-chibi proportions — head slightly oversized relative to the
body, petite elegant limbs, stylized anatomy that reads as cute but capable. Clean precise
digital linework with subtle line weight variation and no rough strokes. Rendering is a
hybrid of cel shading and painterly gradients: smooth transitions between shadows,
airbrushed skin, glossy hair highlights with fine strand separation, metallic sheen on
armor and weapons. Lighting is cinematic and atmospheric — warm ambient bloom, rim lighting
around hair and armor edges, floating light particles, soft environmental haze. Composition
is dynamic and character-centered: motion flow, perspective exaggeration, and depth-of-field
blur push the character forward. Weapons are oversized and decorative. Backgrounds are soft-
focus RPG environments — castle courtyards, magical interiors, atmospheric ruins — that
support the character rather than compete. The overall register is magical, heroic, and
elegant — premium anime production quality in every detail.

### Style Negatives
restrained static composition, monochrome palette, rough hand-drawn linework, flat cel shading, watercolor texture, desaturated muted colors, grounded realism, minimal backgrounds

### ChatGPT Translation
```
Modern fantasy anime gacha splash art aesthetic — semi-chibi proportions with slightly
oversized head and petite elegant body, clean precise digital linework, hybrid cel shading
with painterly gradients and airbrushed skin, glossy layered hair highlights with fine
strand separation, metallic armor sheen, cinematic anime lighting with warm bloom, rim
lighting on hair and armor edges, floating atmospheric light particles, dynamic
character-centered composition with motion flow and depth-of-field background blur,
oversized decorative fantasy weapon or magical effect, soft-focus RPG fantasy environment
background, magical heroic and elegant mood, VTuber key visual and JRPG splash art quality.
```

### Niji Journey Translation
```
gacha splash anime art, semi-chibi proportions, clean precise linework, hybrid cel shading painterly gradients, glossy hair highlights, warm bloom rim lighting, floating particles, dynamic motion composition, depth of field
--ar 2:3
```

---

## STYLE: Cinematic Anime
**Aliases:** cinematic anime, studio anime, anime key art, premium anime illustration, anime concept art, visual novel art
**Best for:** character portraits with real-world equipment, motorsport and race characters, action characters at rest, fantasy OCs in grounded settings, strong directional lighting scenes, high production quality without photorealism
**Conflicts with:** Hyperreal Anime (photorealistic skin/materials vs. illustrated), flat cel shading, chibi proportions, Ironbloom flat/ink sub-mood (ink lines vs. painted rendering)

### Visual Description
High-quality 2D anime digital illustration with cinematic lighting and production values.
Rendering stays firmly within anime illustration language — smooth clean anime skin with no
photographic texture, material detail that reads as expertly illustrated rather than
photographically accurate. Leather looks like drawn leather. Sweat and grime are rendered
in anime vocabulary: beaded sweat drops, illustrated dirt smudges, stylized wear. Lighting
is strong and directional — hard shadows, warm color grading, rim light on hair and
shoulders — but it illuminates an illustration, not a render. Natural anime proportions
throughout; nothing crosses into 3D or photorealistic territory. The overall register is
the premium production quality of high-end game concept art, visual novel key visuals, or
prestige anime promotional art.

### Style Negatives
photorealistic skin texture, 3D rendering, flat cel shading, chibi proportions, rough hand-drawn linework, watercolor texture, monochrome palette, soft ambient-only lighting

### ChatGPT Translation
```
High-quality 2D anime digital illustration with cinematic lighting — smooth clean anime
skin with no photographic texture, illustrated material detail with depth and volume on
clothing and gear, strong directional sunlight with warm golden color grading, hard shadows
and rim lighting, rendering that stays clearly within anime illustration language throughout,
anime-style detail language for sweat and wear, natural anime proportions, premium game
concept art or visual novel illustration quality.
```

### Niji Journey Translation
```
cinematic anime illustration, smooth clean anime skin, strong directional sunlight, warm golden color grading, hard shadows rim lighting, natural anime proportions
--ar 2:3
```

---

## STYLE: Hyperreal Anime
**Aliases:** hyperreal anime, photoreal anime, semi-realistic anime, 3D anime, realistic anime, chillout, cinematic anime portrait
**Best for:** elf/fantasy OC portraits, character close-ups, race-suit or armored characters with real material texture, emotionally quiet portrait moments, scenes where anime stylization meets photographic lighting
**Conflicts with:** flat cel shading, retro/grain aesthetics, chibi proportions, hard ink outlines, heavy stylization

### Visual Description
A rendering aesthetic where anime character design — expressive eyes, stylized facial structure,
fantasy features like pointed ears — meets near-photographic realism in everything else.
Skin has actual texture: pores, freckles, sweat, subtle imperfection. Clothing and armor
read as real materials — worn leather, fabric weave, scratched metal. Lighting behaves like
real light: bokeh backgrounds, lens flare, rim lighting from a physical source. Depth of field
is present and optically correct. The result sits in an uncanny sweet spot — clearly not a
photo, but rendered with enough physical accuracy that the fantasy elements feel grounded.

Two primary sub-moods:

- **Gritty / Dynamic:** Strong directional sunlight, physical grime and sweat on skin and
  costume, highly detailed gear with real wear, warm afternoon color grading. Energy is
  present — the character has been doing something. Used for racers, warriors, mechanics,
  action characters at rest.

- **Soft / Dreamy:** Overexposed, backlit, soft bokeh, drifting particles, pastel lens
  atmosphere. The character is emotionally inward — eyes closed or downcast, contemplative.
  Used for quiet moments, emotional beats, ethereal fantasy portraits.

Both sub-moods share the semi-photorealistic rendering foundation.

### Style Negatives
flat cel shading, retro analog grain, hard ink outlines, chibi proportions, heavy stylization, flat color fills, minimal shading, cartoon proportions, watercolor texture

### ChatGPT Translation

**Gritty sub-mood:**
```
Semi-realistic anime portrait — anime character design with highly detailed rendering quality.
Real skin texture with sweat and subtle imperfection, physically detailed material on worn
leather and gear, strong directional afternoon sunlight casting hard shadows, warm golden
color grading, shallow depth of field with soft bokeh background, cinematic realism, high
detail on clothing wear and surface grime, semi-realistic anime rendering with anime
stylization preserved in the face and proportions.
```

**Dreamy sub-mood:**
```
Semi-realistic anime portrait — anime character design with detailed soft rendering. Real
skin texture, soft freckles, subtle facial imperfection. Heavily backlit with overexposed
warm light, soft bokeh and drifting light particles, dreamy shallow depth of field, lens
flare and atmosphere haze, muted pastel color grading, emotionally inward pose, eyes
downcast or closed, quiet contemplative mood, semi-realistic anime rendering with anime
stylization preserved throughout.
```

### Niji Journey Translation

**Gritty sub-mood:**
```
semi-photorealistic anime, hyperreal rendering, physical material texture, sweat on skin, strong directional sunlight, warm afternoon color grade, shallow depth of field, soft bokeh
--ar 2:3
```

**Dreamy sub-mood:**
```
semi-photorealistic anime, hyperreal soft rendering, skin texture with freckles, dreamy backlit atmosphere, overexposed warm light, soft bokeh, floating particles, pastel lens haze
--ar 2:3
```

### Block Pre-fills (when loaded)

| Block | Value |
|---|---|
| Block 5 — Lighting | Physically accurate light source; directional sun (gritty) or backlit overexposed warm (dreamy); lens flare; bokeh-correct depth of field |
| Block 6 — Style | Semi-realistic anime; highly detailed anime character with stylization preserved in face and proportions; detailed material textures |
| Block 7 — Mood & Palette | Gritty: warm golden afternoon, high detail, worn surfaces. Dreamy: soft pastel overexposure, drifting particles, emotional stillness |

---

Output formats define *structure and layout*, not visual aesthetics. They are applied
alongside a visual style, not instead of one. When an output format is requested, load
its dedicated reference file and ask the user which visual style to pair with it.

---

## FORMAT: Character Sheet
**Aliases:** character sheet, ref sheet, refsheet, model sheet, turnaround sheet, character reference
**Pairs with:** any visual style — always ask which style to apply
**Reference file:** `references/character-sheet.md`

A production-quality anime character reference sheet covering up to 12 panels: full-body
turnaround, expression grid, hair breakdown, outfit breakdown, equipment sheet, weapon sheet,
color palette, action pose, scale reference, and silhouette panel. Designed to feel like a
professional game or anime studio production asset. Visual style is determined separately.

**When invoked:** load `references/character-sheet.md` for full layout spec, then ask:
> "Which visual style should the sheet use? (e.g., Ironbloom, Aquarelle, Ember — or describe
> your own)"

**Aspect ratio:** 16:9 (preferred) · 21:9 (large sheets)

---

## STYLE: Velvet
**Aliases:** velvet, luxury dark fantasy anime, crimson violet anime, Pixiv masterpiece, premium dark gacha, dark fantasy key visual, velvet luxury, satin anime
**Best for:** elegant dark-fantasy characters in luxury or supernatural settings, formal attire with lustrous materials, moody character portraits in crimson and violet lighting, premium dark gacha-style key visuals, characters who radiate dangerous elegance
**Conflicts with:** Daily Chibi, Moe Gacha, Webtoon, Botanical Lineart, Tactical Ink — too casual, flat, hand-drawn, or pastel; Kurosawa, Crewdson — live-action aesthetics that undercut the anime rendering base

### Visual Description
A premium dark-fantasy anime key visual defined by polished, layered rendering and a
signature crimson-violet palette. Unlike atmospheric styles that suppress detail into haze,
Velvet renders with lustrous precision: smooth gradient shadows, refined anime line art,
and glossy digital rendering that makes satin, velvet, and silk materials catch the light
with jewel-like quality.

Lighting is richly layered — soft bloom highlights, subtle rim lighting, and diffused
city-light bokeh working in concert to give the image depth without harshness. Eyes are
rendered with particular brilliance: luminous, detailed, immediately commanding. Character
design is elegant and composed — clean anime facial structure, sophisticated expression,
never casual or energetic.

The background is present through soft-focus depth of field: city lights, dark interiors,
or atmospheric environments rendered as bokeh and diffused glow rather than sharp detail
or abstracted haze.

The palette is non-negotiable: deep crimson and violet with atmospheric neon noir undertones.
Controlled contrast and sophisticated color harmony prevent the image from feeling garish
despite its richness. The result is a modern Pixiv masterpiece aesthetic — high-end dark
gacha key visual quality that feels like premium printed art.

### Style Negatives
flat cel shading, painterly texture, sketch lines, atmospheric suppression, lost-and-found edges, chibi proportions, dynamic action poses, casual aesthetic, pastel palette, muted desaturated colors, rough hand-drawn linework

### Usage Notes
- **Palette is fixed:** deep crimson and violet are the signature colors; don't swap for
  user-requested palettes — offer a different style if another palette is needed.
- **"Polished" means smooth gradients and refined lineart:** not cel shading, not painterly
  texture, not graphic flatness — smooth and glossy throughout.
- **Don't confuse with Gacha Splash:** Gacha Splash is dynamic, energetic, often semi-chibi;
  Velvet is still and elegant — portraits and composed scenes, not action shots.
- **Materials are a feature:** explicitly describe satin, velvet, silk, or other lustrous
  fabrics in the prompt when relevant — they define the style's surface quality.

### ChatGPT Translation
```
Cinematic anime key visual, premium Pixiv masterpiece quality, high-end dark-fantasy gacha
illustration. Polished soft-rendered anime shading with refined anime line art and smooth
gradient shadows. Glossy digital rendering on reflective satin and velvet materials.
Signature palette: deep crimson and violet lighting with atmospheric neon noir undertones,
sophisticated color harmony, controlled contrast. Richly layered lighting: soft bloom
highlights, subtle rim lighting, diffused city-light bokeh. Luminous eyes as primary focal
anchor — detailed, brilliant, immediately commanding. Elegant character design with clean
anime facial structure. Moody nighttime ambiance, ethereal cinematic atmosphere. Soft-focus
background with shallow depth of field — city lights or dark interior as diffused bokeh
rather than sharp detail. Highly detailed but stylized anime rendering — smooth shading
transitions, refined linework. No painterly texture. No lost-and-found edges. No atmospheric
suppression. No flat cel shading. No photorealistic surface detail.
```

### Niji Journey Translation
```
cinematic anime key visual, polished soft-rendered shading, refined line art, glossy digital rendering, satin velvet fabric, deep crimson violet palette, soft bloom highlights, rim lighting, city-light bokeh, luminous detailed eyes
--no painterly texture, sketch lines, flat cel shading, chibi, dynamic action pose
--ar 2:3
```

---

## STYLE: Daily Chibi
**Aliases:** daily chibi, chibi daily, cozy chibi, casual chibi, nichijou, slice chibi, SD daily life, everyday chibi, chibi slice of life, off-duty chibi
**Best for:** everyday slice-of-life scenes, characters eating or relaxing, restaurant/cafe/home interiors, mundane activities rendered with warmth, food scenes, off-duty character moments
**Conflicts with:** Moe Gacha (extreme SD mascot proportions and product-key-art presentation vs. semi-chibi grounded in a lived-in scene), Dark Fantasy, Soulslike, Tactical Ink, Kurosawa — anything requiring dramatic atmosphere, action energy, or dynamic composition

### Visual Description
Semi-chibi proportions — head roughly one-quarter of total height, slightly enlarged but far
less extreme than full chibi. The character is always in a mundane, everyday context: eating
a meal, sitting at a desk, browsing a phone, standing in a convenience store. The scene around
them is the point — food, furniture, and everyday objects are rendered with genuine care and
visual weight. Clean flat cel shading with soft rounded forms. Warm ambient interior lighting
from a natural or overhead source. Expressions are typically understated: neutral, quietly
unamused, tired, or softly content. The appeal is the contrast between the slightly-oversized
anime head and the very grounded, believable world the character inhabits. Feels like a gacha
character's day off.

### Style Negatives
dramatic atmosphere, action energy, dynamic composition, dark fantasy, heavy shadows, bold thick outlines, complex detailed backgrounds, neon lighting, extreme chibi proportions, painterly rendering

### ChatGPT Translation
```
Anime semi-chibi slice-of-life illustration — slightly enlarged head with soft rounded anime
proportions, clean flat cel shading, character in a casual everyday pose surrounded by a
carefully rendered interior setting (restaurant, cafe, bedroom, kitchen), detailed everyday
objects — food dishes, tableware, furniture — given genuine visual weight, warm ambient
interior lighting, understated or quietly unamused expression, clean anime linework, cozy and
grounded mood, anime slice-of-life and gacha daily life aesthetic, 2D anime illustration style.
```

### Niji Journey Translation
```
semi-chibi anime, slightly oversized head, clean flat cel shading, slice of life interior, carefully rendered everyday objects, warm ambient lighting, clean anime linework
--ar 1:1
```

---

## STYLE: Gossamer
**Aliases:** gossamer, light novel, visual novel, visual novel cg, soft anime, pastel anime, soft fantasy, healing anime, iyashikei, fantasy portrait, shrine maiden, light novel illustration, porcelain anime
**Best for:** fantasy portraiture, visual novel CGs, light novel character illustrations, iyashikei and healing atmosphere scenes, elegant character showcases, spring or summer fantasy environments, floral scenes, tranquil interiors, fantasy fashion, elves, shrine maidens, noblewomen, romantic character art, serene magical settings
**Conflicts with:** Miura, Soulslike, Neon Noir, Ironbloom, Cinematic Anime, Hyperreal Anime, Kurosawa, Crewdson — anything dark, gritty, high-contrast, dramatic, or with strong directional lighting

### Visual Description
A clean flat modern anime aesthetic defined by minimal shading complexity and deliberate
color restraint. Line art is very thin and barely visible — soft grey or colored lines
rather than black ink, creating gentle form separation without hard edges. Shading is
flat cel-style with only one or two shadow tones, no gradients, no blending, and dark
values lifted so high the image reads nearly shadowless. Lighting is completely ambient
with no directional source — no cast shadows, no rim light, no highlight drama. Colors
are muted and slightly cool: sage greens, dusty blues, warm off-whites, and soft aquas
hold their saturation better than full pastels but avoid vibrancy. Backgrounds are
deliberately simplified — soft architectural suggestion, blurred foliage, washed-out
water — never detailed enough to compete with the figure. Hair reads as flat smooth
planes with a single controlled shine streak rather than strand-level rendering. Skin
is clean and textureless with a faint warm blush on cheeks only. Eyes are large and
flat-irised, rendered in cool aqua or grey-blue with no complex reflections. The overall
effect is quiet, weightless, and illustrative — closer to a clean Pixiv sketch with
intentional color holds than a fully rendered painting.

### Style Negatives
bold outlines, thick linework, black ink outlines, heavy shadows, dramatic lighting, directional light, rim lighting, gradients, painterly rendering, complex shading, vibrant saturated colors, dark palette, high contrast, photorealistic, detailed backgrounds

### ChatGPT Translation
```
Soft flat modern anime illustration — extremely thin soft-colored outlines barely visible
against form edges, flat cel shading with only one shadow tone and lifted dark values that
make the image read nearly shadowless, no gradients or blending on skin or fabric,
completely ambient lighting with no directional source or cast shadows, muted slightly
cool color palette where sage greens and dusty aquas hold mild saturation without going
fully pastel, simplified blurred background with no competing detail, hair as flat smooth
planes with a single shine streak and no strand detail, clean textureless skin with faint
blush on cheeks only, large flat-irised eyes in cool aqua or grey-blue. Drawn as a clean
flat light novel illustration — minimal, weightless, and illustrative. No painterly
rendering, no complex shading, no photorealism, 2D anime art style.
```

### Niji Journey Translation
```
soft flat anime, barely visible thin outlines, flat cel shading single shadow tone, no gradients, ambient lighting, muted cool palette sage green dusty aqua, blurred simplified background, light novel illustration
--ar 2:3
```

---

## STYLE: Flat Chibi
**Aliases:** flat chibi, chibi flat, graphic chibi, sticker chibi, pop chibi, flat gacha chibi, clean chibi
**Best for:** any chibi character in dynamic action regardless of genre — fantasy warriors, magical girls, school uniforms, sci-fi pilots, sports characters, mecha suits. Full chibi action-art proportions rendered with Flat Cel's technique instead of soft gradients. Palette fully user-defined.
**Conflicts with:** Moe Gacha (Moe Gacha is a still, extreme-SD mascot with soft gradient/bloom rendering; Flat Chibi is dynamic action-chibi with completely flat rendering), Gacha Splash, Ember, Makoto Shinkai, Hyperreal Anime, Cinematic Anime, Aquarelle, Velvet — anything requiring gradient rendering, atmospheric lighting, or painterly depth.

### Visual Description
Full chibi action-art proportions rendered through Flat Cel's technique. The head is one-third to one-half of total body height — a tiny-but-capable figure rather than the more extreme mascot scale of Moe Gacha — with a tiny capable body, oversized weapons or props, and detailed outfits or equipment across any genre. Everything renders flat: a single hard-edged shadow tone with lifted dark values, no gradients, no blending, no atmospheric glow or bloom. Line art is clean and thin with consistent weight. Outfits and armor have flat color fills with no metallic sheen or highlight drama. Weapons and props are oversized and bold but rendered as flat graphic blocks rather than detailed metallic rendering. Hair reads as flat smooth planes with a single shine streak. Particles and debris are simplified flat graphic shapes rather than atmospheric effects. Backgrounds are flat and minimal — never detailed, never competing. Lighting is completely ambient — no bloom, no rim light, no floating atmospheric particles. Poses are dynamic and action-oriented, unlike Moe Gacha's still mascot presentation. Palette is fully user-defined. The result feels like high-quality mobile game sticker art, a bold LINE character, or a flat graphic game icon — cute, readable, and graphically confident. Distinct from Moe Gacha (extreme SD mascot proportions, soft gradient rendering, still pose) and Daily Chibi (semi-chibi, static, slice-of-life).

### Style Negatives
gradients, blending, painterly texture, bloom, atmospheric particles, rim lighting, metallic sheen, highlight drama, detailed competing backgrounds, complex shadow rendering, photorealistic rendering, regular proportions

### Usage Notes
- Full chibi action proportions (head one-third to one-half of height) with Flat Cel's rendering technique
- Unlike Moe Gacha: dynamic action pose rather than still mascot presentation; completely flat rendering rather than soft cel shading with airbrushed gradients and bloom
- Unlike Daily Chibi: action-focused with dynamic poses, not slice-of-life; full chibi not semi-chibi
- Unlike Flat Cel: full chibi proportions only — not for regular-proportioned characters
- Palette fully user-defined per scene — specify in Block 7

### ChatGPT Translation
```
Flat cel chibi anime illustration — full chibi proportions with head one-third to one-half of total body height, single hard-edged shadow tone and lifted dark values reading nearly shadowless, no gradients or blending, flat color fills inside outfit and equipment with no metallic sheen or atmospheric glow, clean thin line art with consistent weight, oversized weapon or prop rendered as flat graphic block at chibi scale, detailed character outfit or equipment in flat style (any genre — fantasy armor, school uniform, sci-fi suit, magical costume), flat smooth hair planes with a single shine streak, simplified flat graphic debris and particle shapes, flat minimal background suited to scene setting, [user-defined palette and mood]. Drawn as a clean flat chibi anime illustration, 2D anime art style, no painterly texture, no complex shading, no atmospheric lighting.
```

### Niji Journey Translation
```
flat cel chibi anime, full chibi proportions, single shadow tone no gradients, flat color fills, clean thin line art, oversized weapon chibi scale, flat minimal background, [user-defined palette]
--ar [ratio]
```

---

## STYLE: Flat Cel
**Aliases:** flat cel, flat shading, flat anime, clean flat, cel flat, modern flat, flat illustration, flat style
**Best for:** any scene regardless of theme or genre — action, dark fantasy, romance, slice-of-life, comedy, horror, supernatural, school life, urban, sci-fi, fantasy. Palette and mood are fully user-defined per scene. Use when you want Gossamer's flat rendering without its palette or theme constraints.
**Conflicts with:** Aquarelle, Ember, Studio Ghibli, Makoto Shinkai, Hyperreal Anime, Cinematic Anime, Miura, Velvet — anything requiring gradients, painterly texture, volumetric lighting, complex shadow rendering, or photorealistic surface detail.

### Visual Description
The core technique of flat digital anime illustration, extracted from any specific mood or palette and made fully universal. Shading is flat cel-style with a single hard-edged shadow tone and lifted dark values that make the image read nearly shadowless. No gradients, no blending, no painterly texture, no brushstroke quality. Lighting is completely ambient — no directional source, no cast shadows, no rim light or highlight drama. Line art is clean and thin with consistent weight — slightly more defined than Gossamer's barely-visible style, providing readable form separation across all genres and palettes. Hair reads as flat smooth planes with a single shine streak. Skin is clean and textureless. Backgrounds are simplified and flat, never rendered with depth or complexity that competes with the figure. The palette is fully open and user-defined: vibrant, muted, warm, cool, dark, or light — whatever serves the scene. Dark themes are carried through palette choice rather than lighting — deep muted tones and desaturated color convey atmosphere without shadows. Gossamer is a specific application of this style (cool palette + iyashikei atmosphere); Flat Cel is the unrestricted base technique.

### Usage Notes
- **Palette:** fully user-defined — specify in Block 7 for every prompt. There is no default palette.
- **Mood:** fully user-defined — specify in Block 7 for every prompt.
- **Gossamer vs. Flat Cel:** If the user wants the muted cool palette and healing atmosphere, use Gossamer. If they want the flat technique with freedom to define palette and theme, use Flat Cel.
- **Dark themes:** handled through palette (deep muted tones, desaturated colors) — not through shadows or lighting drama.

### Style Negatives
gradients, blending, painterly texture, brushstroke quality, volumetric lighting, directional light, cast shadows, rim lighting, highlight drama, photorealistic rendering, complex shadow rendering, detailed competing backgrounds

### ChatGPT Translation
```
Flat cel anime illustration — clean thin line art with a single hard-edged shadow tone and lifted dark values reading nearly shadowless, no gradients or blending, completely ambient lighting with no directional source or cast shadows, simplified flat background, hair as smooth flat planes with a single shine streak, clean textureless skin, [user-defined palette and mood per scene]. Drawn as a clean flat modern anime illustration, 2D anime art style, no painterly texture, no complex shading, no photorealism.
```

### Niji Journey Translation
```
flat cel shading anime, single shadow tone no gradients, ambient lighting, clean thin line art, flat smooth hair, simplified flat background, [user-defined palette]
--ar [ratio]
```

---

## STYLE: Sketch Moe
**Aliases:** sketch moe, bold sketch, g-pen moe, rough moe, bold moe, minimal moe, pen moe, cute sketch
**Best for:** cute original characters, fantasy girls, market/shop scenes, character showcases with warm charm, any scene where bold readable outlines and minimal detail create a hand-crafted storybook warmth — proportions and palette fully user-defined
**Conflicts with:** Hyperreal Anime, Cinematic Anime, Miura, Velvet — anything requiring complex rendering, gradient shading, volumetric lighting, or high detail density. Also conflicts with Gossamer and Flat Cel — shares flat coloring but the bold linework and hand-drawn wobble are fundamentally different from their thin/clean line approaches

### Visual Description
Bold, confident outlines reminiscent of traditional G-pen manga inking — the lines carry
the illustration. Weight varies naturally with pressure, thicker on outer contours and
thinner on interior details. A subtle hand-drawn wobble and texture gives the linework
warmth and imperfection without sacrificing clarity. The character is constructed with
only the minimum necessary lines — silhouette readability is prioritized over decorative
detail. Information density is deliberately low. Coloring is soft flat fills with muted
saturation and only very subtle shading — no heavy gradients, no painterly rendering, no
dramatic lighting. Proportions are semi-deformed: the head is slightly enlarged but not
chibi-extreme, the body is slender and elegant with slightly longer limbs, creating a
delicate youthful silhouette that avoids both mascot-like stockiness and normal realism.
Facial features are positioned slightly lower on the face for maximum cuteness — small
chin, short mid-face, tiny simple mouth, nearly omitted nose. Backgrounds are simplified
and softened so the character's silhouette and expression remain the clear focus. The
overall effect is a warm, hand-crafted illustration that feels like premium doujinshi
cover art or a high-quality Pixiv rough-with-flats piece.

### Style Negatives
photorealistic, heavy gradients, painterly rendering, complex shading, volumetric lighting, dramatic shadows, thin invisible outlines, excessive detail, intricate decorations, realistic proportions, stocky or muscular build, extreme chibi proportions, oversized head mascot proportions

### Usage Notes
- **Proportions:** semi-deformed by default (slightly enlarged head, slim elegant body). Can be pushed toward more chibi or more normal per user request, but the sweet spot is between the two.
- **Palette:** fully user-defined — specify in Block 7. No default palette.
- **Linework is the identity:** if the user wants thin or invisible outlines, redirect to Gossamer or Flat Cel instead.

### ChatGPT Translation
```
Anime illustration with bold G-pen-style outlines — confident thick-to-thin linework with
natural pressure variation and subtle hand-drawn wobble giving warmth and texture, character
constructed with minimum necessary lines prioritizing silhouette readability over decorative
detail, soft flat color fills with muted saturation and only very subtle shading, no heavy
gradients or painterly rendering, semi-deformed proportions with slightly enlarged head and
slender elegant body with delicate elongated limbs, facial features positioned low on the
face for cuteness — small chin tiny mouth nearly omitted nose, simplified softened background
keeping character as clear focus, [user-defined palette and mood per scene], warm hand-crafted
illustration quality, 2D anime art style.
```

### Niji Journey Translation
```
bold G-pen outlines thick-to-thin linework, hand-drawn wobble, soft flat color fills muted saturation, semi-deformed proportions slender elegant body, simplified soft background, [user-defined palette]
--ar [ratio]
```

---

## ADD YOUR OWN STYLE

Copy this template and fill it in:

```
## STYLE: [Name]
**Aliases:** [name], [alias 1], [alias 2]
**Best for:** [subject types this suits]
**Conflicts with:** [things to avoid]

### Visual Description
[2–4 sentences describing the look, feel, and key visual codes of this style]

### Style Negatives
[Comma-separated list of things that break this style. These get auto-appended to the
negative prompt / --no flag when this style is loaded. Focus on rendering approaches,
shading methods, proportion types, and aesthetic clashes — not subject matter.]

### ChatGPT Translation
[Prose language to weave into the ChatGPT prompt — 1–3 sentences]

### Niji Journey Translation
[Keyword-dense form + any recommendation]
```

---

## STYLE: Pixiv Clean
**Aliases:** pixiv clean, pixiv, clean anime, clean illustration, elf portrait, pixiv portrait, pixiv oc
**Best for:** original character portraits, elf and fantasy OCs, sitting or relaxed poses, character showcases, any scene where fabric detail and clean faces are the focus — white background or with a scene background
**Conflicts with:** heavily rendered styles, painterly backgrounds, complex lighting setups, Hyperreal Anime, Cinematic Anime, Aquarelle, Velvet — anything requiring atmospheric depth or photorealistic rendering

### Visual Description
A clean, polished Pixiv illustration style defined by confident medium-weight linework and a
deliberate contrast between face rendering and fabric rendering. Lines taper naturally at hair
tips and fabric edges but never disappear. Shading is soft cel-style with one or two flat
shadow passes — skin is smooth and luminous without crossing into photorealism. The defining
characteristic is fabric: cloth folds use loose, gestural inner lines that feel almost
hand-drawn, giving ruffles and layered clothing a lively quality that contrasts the cleaner
face and skin. Background is user-defined — white is common but a simplified scene background
works equally well. Lighting is soft ambient with no directional source. Face is always the
most refined element. Palette is fully user-defined.

### Style Negatives
painterly backgrounds, complex lighting setups, atmospheric depth, photorealistic rendering, heavy gradients, volumetric lighting, dramatic shadows, rough sketch linework, chibi proportions

### ChatGPT Translation
```
Clean Pixiv anime illustration — confident medium-weight linework with natural taper at hair
tips and fabric edges, soft cel shading with one or two flat shadow passes on skin, smooth
luminous skin rendering that stays firmly 2D, loose gestural cloth fold lines on fabric and
ruffles contrasting the cleaner face rendering, soft ambient lighting with no directional
source or cast shadows, face as the most refined focal element, background and palette fully
user-defined. Drawn as a clean polished Pixiv character illustration — 2D anime art style,
no painterly texture, no photorealism, no complex lighting.
```

### Niji Journey Translation
```
clean Pixiv anime illustration, confident medium-weight linework, soft flat cel shading, smooth luminous skin, loose gestural fabric fold lines, ambient lighting, [user-defined palette]
--ar [ratio]
```

---

## STYLE: Colored Pencil
**Aliases:** colored pencil, colour pencil, pencil art, colored pencil anime, traditional pencil
**Best for:** character portraits, OC showcases, detailed costume and equipment studies, fan art, any subject where a handcrafted traditional-media feel is the point
**Conflicts with:** digital polish, clean cel shading, flat rendering, neon lighting, glossy or luminous skin, photorealistic rendering, Line Art (the two styles directly conflict — Line Art suppresses the layered stroke quality that defines Colored Pencil, and Colored Pencil's hatching undermines Line Art's clean outline requirement. Never combine them.)

### Visual Description
Traditional colored pencil illustration on cream or off-white paper — constructed entirely
from visible individual pencil marks. The illustration should be immediately recognizable as
a photograph of a real colored pencil drawing on paper rather than a digital illustration
imitating colored pencil. Every value, shadow, and color transition is built exclusively from
layered colored pencil strokes — no smooth tonal gradients, no painted shading, no digital
blending of any kind. Contour lines are graphite-colored pencil with slight pressure variation
and occasional broken edges where pigment skips across the paper tooth. Shadows are built
through multiple layers of visible directional strokes with varying pressure and density;
stroke direction follows the three-dimensional form of each surface (armor plates wrap around
the breastplate, greaves follow the shin, cloth strokes follow folds). White areas of armor
are constructed from layers of cool gray, warm gray, and white colored pencil, with individual
strokes remaining visible throughout — highlights are preserved paper left untouched, never
painted white over darker color. Paper grain is consistently visible through every color layer;
pigment skips over paper tooth in lighter passages, leaving natural white flecks even in
colored regions. Ground shadow rendered as scattered pencil strokes, not a hard-edged drop.
Colors have the slightly muted, waxy quality of real colored pencil media. Palette is
user-defined but always reads as a physical colored pencil illustration, not digital.

### Style Negatives
smooth tonal gradients, painterly blending, airbrushed shading, soft digital gradients, polished rendering, painted shadows, digital rendering, clean ink-style outlines, flat cel shading, glossy or luminous skin, neon lighting, gradient backgrounds, airbrush smoothness, photorealistic rendering, vector linework, dense crosshatching clusters, chibi proportions, ink wash, Line Art style

### Prompt Notes
- **Never add a Line Art reference** — the two styles directly conflict and produce scratchy, ambiguous results.
- **The key constraint:** every value must be built from visible pencil strokes — smooth tonal rendering is the primary failure mode, not outline quality.
- **Benchmark output:** cream paper visible through strokes including in colored regions, pressure-variable pencil contours with occasional gaps, directional stroke layers for all shading, natural ground shadow scatter.

### ChatGPT Translation
```
Traditional colored pencil anime illustration on cream paper — constructed entirely from
visible individual colored pencil strokes. This illustration should look like a photograph
of a real colored pencil drawing on paper, not a digital illustration with a pencil texture
overlay. Every shadow, color transition, and value change is built exclusively through layered
colored pencil marks — no smooth blended gradients, no painted tonal rendering. Contour lines
are graphite-colored pencil with slight pressure variation and broken edges where pigment skips
across paper tooth. Shadows built through repeated directional stroke layers with varying
pressure, individual marks visible throughout. Stroke direction follows each surface's
three-dimensional form. White armor constructed from layered cool gray, warm gray, and white
colored pencil strokes — highlights are untouched cream paper, never painted white. Paper
grain visible through every color layer; pigment skips across paper tooth leaving natural
white flecks in lighter passages. Slightly muted waxy colored pencil color quality. 2D anime
proportions. No smooth tonal gradients, no painterly blending, no airbrush smoothness, no
digital rendering, no ink outlines, no dense crosshatch clusters.
```

### Niji Journey Translation
```
traditional colored pencil anime illustration on cream paper, every surface built from visible layered pencil strokes, pressure-variable pencil contours broken edges, directional stroke shading follows surface form, paper grain visible through color layers, waxy colored pencil quality, natural scattered ground shadow, [user-defined palette]
--no smooth gradients, digital rendering, painterly blending, airbrush smoothness, ink outlines, cel shading, dense crosshatching
--ar [ratio]
```

---

## STYLE: Brick Diorama
**Aliases:** brick diorama, voxel diorama, block art, lego diorama, interlocking brick, isometric brick scene, building brick art
**Best for:** cute animal scenes, miniature houses and gardens, toy-like characters, cozy dioramas, small worlds built from interlocking plastic bricks
**Conflicts with:** smooth organic rendering, realistic proportions, dark moody themes, detailed facial expressions

### Visual Description
Isometric miniature diorama rendered as a premium collectible building brick model on a clean
background. All elements — characters, buildings, trees, props — are constructed from genuine
interlocking plastic building bricks on a fixed stud grid, assembled using standard bricks,
plates, tiles, slopes, curved slopes, wedges, and round elements. Every element snaps precisely
to the stud grid with no floating or off-grid pieces. Exposed circular studs visible on top
surfaces with consistent spacing. Individual bricks remain identifiable through narrow seams and
stacked construction. Injection-molded ABS plastic with subtle satin sheen, authentic chamfered
plastic brick edges, tiny molded seams, realistic contact shadows. Isometric camera angle with
shallow tilt-shift depth of field creates a miniature model feel. Warm soft studio lighting.
Warm cheerful palette with natural material colors — wood grain browns, mossy greens, warm stone
greys. Characters are simplified and cute, built from stacked bricks with minimal facial features.
The scene sits on a small baseplate like a collectible display piece. Overall feel is cozy,
handcrafted, and toy-like.

### Style Negatives
sculpted voxel cubes, Minecraft-style blocks, MagicaVoxel render, fused geometry, melted block surfaces, seamless shapes, off-grid pieces, floating bricks, irregular brick sizes, smooth organic forms, dark moody lighting, complex facial expressions, photorealistic textures, flat 2D, ink outlines, cel shading, painterly blending, neon lighting

### ChatGPT Translation
```
Isometric realistic interlocking plastic brick diorama — a miniature collectible scene
constructed entirely from authentic interlocking plastic building bricks on a precise stud
grid. Every object is assembled using standard bricks, plates, tiles, slopes, curved slopes,
wedges, and round elements while remaining fully constrained to physically plausible brick
construction. Individual bricks remain visible through narrow seams and exposed circular studs
with consistent spacing across the model. Every element snaps precisely to the stud grid with
no floating or off-grid pieces. Injection-molded ABS plastic with subtle satin reflections,
authentic chamfered plastic brick edges, tiny part gaps, consistent manufacturing tolerances,
authentic toy-scale proportions. Characters simplified into cute brick-built forms with minimal
dot-eye faces. Scene sitting on a small baseplate like a collectible display piece, clean white
background. Photographed like a premium collectible building brick display model using macro
lens, warm soft studio lighting, shallow tilt-shift depth of field, realistic plastic
reflections, and gentle contact shadows.
```

### Niji Journey Translation
```
isometric interlocking plastic brick diorama, building brick model, stud grid construction, brick seams and exposed studs, ABS plastic satin finish, miniature collectible scene, tilt-shift depth of field, soft studio lighting, warm natural palette, cute simplified characters, clean white background
--ar [ratio]
```

---

## STYLE: Line Art
**Aliases:** line art, lineart, clean linework, ink outline, character lineart, black ink outline
**Best for:** character portraits, OC showcases, costume and equipment studies, coloring book pages, character sheets, fan art — any subject where clean controlled black ink outlines are the point
**Conflicts with:** color fills, shading, tonal rendering, ink washes, hatching, grey tones, painterly blending, flat cel shading, glossy rendering, photorealistic textures

### Visual Description
Clean black ink line art on white paper — pure linework only, no color fills and no tonal rendering of any kind. Strict two-tier line weight system: thick bold confident lines define all outer silhouettes and major structural edges; noticeably thinner lines handle all interior details and surface seams. The contrast between thick and thin is clearly visible and deliberate — not subtle. Armor and costume surface decoration is simplified to clean geometric structural shapes only — no dense filigree, no intricate engraving, no competing interior line clusters. Every line is a single confident stroke — no sketchy repeated lines, no scratchy multi-stroke edges. Coloring book quality linework: every mark serves a clear structural purpose. White paper is fully visible everywhere. Professional character sheet linework feel.

### Style Negatives
color fills, shading, hatching, crosshatching, grey tones, ink washes, watercolor, gradients, dense filigree, intricate engraving, scratchy linework, repeated overlapping strokes, flat cel shading, painterly blending, airbrush smoothness, photorealistic rendering, chibi proportions

### ChatGPT Translation
```
Clean black ink line art illustration on white paper — pure linework only, no color fills,
no shading, no tonal rendering. Strict two-tier line weight system: thick bold confident lines
define all outer silhouettes and major structural edges, noticeably thinner lines handle all
interior details and surface seams — the contrast between thick and thin is clearly visible
and deliberate. Costume and armor surface decoration simplified to clean geometric structural
shapes only, no dense filigree or intricate engraving. Single confident ink strokes only —
no sketchy repeated lines, no scratchy multi-stroke edges. Coloring book quality linework,
professional character sheet feel. White paper fully visible everywhere. 2D anime proportions.
```

### Niji Journey Translation
```
clean ink line art no fill no shading, two-tier line weight thick silhouette outlines thin
interior details, single confident strokes, coloring book linework quality, simplified armor
panels minimal surface decoration, white background, professional character sheet,
2D anime proportions
--no color fill, shading, hatching, grey tones, dense filigree, scratchy lines, gradients,
cel shading, chibi
--ar [ratio]
```

---

## STYLE: Atelier
**Aliases:** atelier, value-driven anime, painterly editorial anime, graphic value painting, hybrid cel painterly, editorial key visual
**Best for:** editorial anime key visuals, graphic character illustrations where shape and value design matter more than rendering density, symmetrical centered portraits, illustrations meant to read as intentionally designed rather than heavily rendered — any genre or palette
**Conflicts with:** Cinematic Anime (illustrated material depth and hard directional shadows vs. restrained lines and large value masses), Hyperreal Anime, Miura (dense photographic-leaning rendering vs. simplified value design), Flat Cel and Gossamer (fully flat/ambient/no-gradient technique vs. Atelier's painterly gradients and directional light), Ironbloom rendered sub-mood (detail-heavy armor rendering vs. Atelier's detail economy)

### Visual Description
A clean contemporary 2D anime illustration built as a hand-painted editorial key visual rather than a rendered image. Graphic design, readable shape language, and value organization take priority over realism or rendering complexity — every form starts as a large simple value mass before any detail is added. Line art is restrained: silhouettes stay clean and confident while interior contours stay minimal, with many internal edges intentionally lost into shadow (lost-and-found edge control) instead of being outlined. Rendering is a hybrid of simplified cel shading and painterly value grouping, organized into roughly three to five major value groups — broad unified shadow masses, soft ambient fill, gentle gradients, restrained reflected light, and only small localized occlusion shadows. Detail is applied selectively: the highest finish sits around the eyes, face, and hair framing the face, while clothing, background, lower body, and secondary props stay intentionally simplified. All materials — skin, cloth, leather, and any other surfaces — share one cohesive matte treatment; different materials read through silhouette, color, and edge quality rather than gloss or texture. Hair is built from large grouped locks with strand detail only near the bangs and silhouette; large secondary shapes (wings, cloaks, props) read first as bold graphic forms rather than densely rendered detail. The one-dominant-light-plus-soft-ambient-fill-plus-restrained-rim lighting structure stays fixed, but palette and light color are fully open — warm, cool, neutral, vibrant, or muted, whatever the scene calls for.

### Usage Notes
- **vs. Cinematic Anime:** Cinematic Anime renders every material with illustrated depth and uses hard directional shadows for cinematic drama. Atelier restrains linework and detail, organizes the whole image into 3–5 broad value masses, and concentrates finish only on the face/hair — the result reads as a graphic editorial illustration rather than a densely rendered key visual.
- **Palette:** fully user-defined — specify in Block 7 for every prompt. There is no default palette; the technique (restrained line, value grouping, detail economy) is what defines this style, not any particular color story.

### Style Negatives
photorealism, hyperrealism, CGI, 3D rendering, physically based rendering, ray tracing, HDR realism, glossy materials, skin pores, realistic skin texture, individually rendered hair strands throughout, individually rendered feathers throughout, intricate lace or textile texture, metallic reflections, excessive specular highlights, micro-detail clutter, over-rendered anime, hyper-polished surfaces, equal rendering density across the whole image, dense competing interior linework

### ChatGPT Translation
```
A clean contemporary 2D anime illustration rendered as a hand-painted editorial key visual, not a rendered image — prioritize graphic design, readable shape language, and painterly value organization over realism or rendering complexity, with every object designed as a large simple value mass before detail is added. Use restrained line art: clean confident silhouettes, minimal interior contour lines, and many internal edges lost naturally into shadow rather than outlined. Render using simplified hybrid cel shading combined with painterly value grouping, organized into three to five major value groups — broad unified shadow masses, soft ambient fill, gentle gradients, restrained reflected light, and only small localized occlusion shadows, avoiding equal rendering density across the whole image. Concentrate the highest finish around the eyes, face, and hair framing the face, while keeping clothing, background, and lower body intentionally simplified. Keep all materials — skin, cloth, leather, and any other surfaces — in one cohesive matte treatment distinguished by silhouette, color, and edge quality rather than gloss or texture. Build hair from large grouped locks with minimal strand definition, and render any large secondary shapes first as bold graphic forms rather than densely rendered detail. Light with one dominant directional light, soft ambient fill, and restrained rim lighting, using [user-defined palette and light color per scene].
```

### Niji Journey Translation
```
hand-painted editorial anime illustration, restrained line art, lost-and-found edges, hybrid cel shading and painterly value grouping, 3-5 value groups, soft ambient fill gentle gradients, detail concentrated on face and hair, matte unified materials, one dominant directional light soft rim, [user-defined palette]
--no glossy materials, skin texture, dense linework, individually rendered feathers, individually rendered hair strands, over-rendered detail
--ar [ratio]
```

---

## STYLE: Forma
**Aliases:** forma, graphic value block, crisp graphic anime, printed anime poster
**Best for:** graphic character illustrations and scenes where crisp clean linework and a tight value economy matter, backdrops (urban, natural, or interior) reduced to simple geometric masses, any illustration wanting a calm, elegant, professionally-printed anime poster look rather than painterly or cinematic rendering — any genre or palette
**Conflicts with:** Atelier (shares the value-shape technique but Forma uses crisp clean linework and a tighter 2-4 value group range instead of painterly lost-and-found edges across 3-5 value groups), Prism, Neon Noir, Ufotable, Makoto Shinkai, Miura, Soulslike — any style relying on bloom, volumetric light, HDR drama, or dense material rendering

### Visual Description
A restrained, graphic anime illustration technique where every object is simplified into a large flat value shape before any detail is added — nothing in the frame is rendered with equal finish. The face carries only slightly more finish than the rest of the image; hair resolves into a small number of clean grouped locks rather than individual strands. Where the scene includes them, feathers or wings read as broad grouped shapes rather than individually painted plumage, lace is suggested through simplified repeating patterns rather than dense mesh texture, and structured clothing seams (corsets, jackets, armor, or otherwise) stay clean and graphic instead of heavily stitched — none of this is assumed by default. Background elements — architecture, foliage, interiors, vehicles, or any other setting the scene calls for — reduce to simple geometric masses with minimal interior detail, and anything distant fades only slightly with depth rather than dissolving into atmosphere. Skin stays smooth and matte with no realistic subsurface rendering, and every material — fabric, leather, metal — is kept fully matte, with no glossy leather, shiny boots, or metallic highlights. The entire image sits inside one unified color grade, lit softly and graphically across only two to four major value groups — no HDR drama, no strong bloom, no volumetric light rays, no cinematic atmospheric haze. Linework is clean, thin, and consistent throughout, with crisp confident silhouettes and minimal interior contour lines; the drawing never dissolves into painterly brushwork. Palette, setting, and subject matter are fully open — whatever genre, theme, and color story the scene calls for; the technique (value simplification, detail economy, crisp thin linework, 2-4 value groups) is what defines Forma, not any particular color story or theme. The mood is calm, elegant, and confident — a graphic illustration that reads like professionally printed anime artwork rather than rendered concept art.

### Usage Notes
- **vs. Atelier:** Both simplify the whole image into large value shapes with detail concentrated on the face, and both leave palette fully open — specify colors in Block 7 for every prompt. The difference is technique: Atelier builds gradients through painterly lost-and-found edges across three to five value groups, while Forma uses crisp clean thin linework instead of painterly edges and restrains the whole image to two to four value groups.
- **Palette, theme, and subject:** fully user-defined — specify in Block 7 for every prompt. There is no default palette or genre; the technique (restrained line, tight value economy, detail concentrated on the face) is what defines this style, not any particular color story or theme. Wardrobe/setting details like corsets, wings, feathers, or lace should only appear in the prompt when the user's scene actually calls for them.

### Style Negatives
photorealism, CGI, concept art rendering, painterly brush texture, volumetric lighting, bloom, lens flare, dense lace texture, individually rendered hair strands, individually rendered feathers, realistic building detail, heavy material rendering, gloss, glossy leather, shiny boots, metallic highlights, realistic cloth rendering, high-frequency texture, over-rendering, HDR lighting, cinematic atmospheric effects

### ChatGPT Translation
```
A restrained, graphic 2D anime illustration where every object is simplified into a large flat value shape before any detail is added — nothing in the frame is rendered with equal finish. The face carries only slightly more finish than the rest of the image; hair is drawn as a small number of clean grouped locks rather than individual strands. Where the scene includes them, feathers or wings read as broad grouped shapes rather than individually painted plumage, lace is suggested through simplified repeating patterns rather than dense mesh texture, and structured clothing seams stay clean and graphic instead of heavily stitched. Background elements — [scene setting] — reduce to simple geometric masses with minimal interior detail, and anything distant fades only slightly with depth. Skin stays smooth and matte with no realistic subsurface rendering, and every material — fabric, leather, metal — is kept fully matte, with no glossy leather, shiny boots, or metallic highlights. The entire image sits inside one unified color grade using [user-defined palette and light color per scene], lit softly and graphically across only two to four major value groups, with no HDR drama, no strong bloom, no volumetric light rays, and no cinematic atmospheric haze. Linework is clean, thin, and consistent, with crisp confident silhouettes and minimal interior contour lines — the drawing never dissolves into painterly brushwork. The mood is calm, elegant, and confident: a graphic illustration that reads like professionally printed anime artwork rather than rendered concept art.
```

### Niji Journey Translation
```
restrained graphic anime illustration, large flat value shapes, clean grouped hair locks, [scene setting] reduced to simple geometric masses, smooth matte skin, unified color grade, [user-defined palette], soft graphic lighting, 2-4 value groups, clean thin consistent anime linework, crisp silhouettes, calm elegant confident mood
--no photorealism, painterly brush texture, volumetric lighting, bloom, individual hair strands, individual feather rendering, gloss, HDR
--ar [ratio]
```

---

## STYLE: Candy Cel
**Aliases:** candy cel, early 2000s anime, millennium moe, y2k anime, tv moe, four-panel anime, aughts moe, classic moe tv anime
**Best for:** cheerful slice-of-life scenes, school comedy moments, small friend-group ensembles, everyday comedic mishaps — the nostalgic simplified moe look of early-2000s Japanese TV anime (four-panel comedy adaptations, school-life sitcoms), not modern gacha or mobile-game moe
**Conflicts with:** Moe Gacha (extreme SD mascot proportions and airbrushed gradient shading vs. this style's milder proportions and flat single-shadow cel work), Retro Anime (80s-90s analog film grain and muted sun-bleached palette vs. this style's cleaner uneven-lineweight cel look and bright candy-saturated palette), Sketch Moe (bold wobbly G-pen outlines vs. this style's cleaner slightly-organic TV-cel linework), Hyperreal Anime, Cinematic Anime, Miura, Soulslike, Neon Noir, Prism — any style relying on realistic rendering, painterly texture, or dramatic cinematic lighting

### Visual Description
The visual language of early-2000s Japanese television anime — cheerful, simplified moe character design built on mildly super-deformed proportions: oversized rounded heads, petite bodies, narrow shoulders, slim limbs, and tiny simplified hands, with minimal noses and mouths. Eyes are enormous and glossy, jewel-toned in saturated blue, violet, or green, ringed with thick upper lashes, carrying exactly two crisp white highlights and only the simplest internal shading — no gradient blending inside the iris. Hair resolves into bold, angular clumps with pointed tips and a distinctive silhouette, rendered in bright pastel color with only one or two flat highlight shapes, never individual strands. Everything is rendered as hand-drawn 2D television animation: outlines are dark but slightly organic with natural unevenness in line weight, colors are uniform flat cel fills, and shading uses exactly one sharply defined shadow tone — no gradients, no soft blending, no glossy modern digital finish. Fabric folds stay sparse and graphic rather than intricately detailed. Expressions are innocent, playful, and comically exaggerated — tiny catlike mouths, broad closed-eye smiles, blush marks, or wide open mouths when excited — and poses read as energetic, awkward, and endearingly comedic rather than elegant. Backgrounds are simple and softly painted with reduced detail and gentle atmospheric color, carrying the feeling of a sunny school-day comedy without ever competing with the characters. Framing is straightforward TV-anime composition with strong readable silhouettes and minimal depth of field. The charming limitations of traditional cel animation production are preserved throughout — slightly uneven line weight, restrained highlights, and simple shadows — rather than smoothed into modern digital polish.

### Style Negatives
photorealism, semi-realistic anatomy, detailed skin texture, painterly rendering, 3D or CGI appearance, complex lighting, dramatic cinematic contrast, excessive gradients, intricate fabric texture, hyper-detailed backgrounds, modern glossy gacha rendering, realistic facial proportions, extreme SD mascot proportions, airbrushed gradient shading, analog film grain, VHS color bleed, bold wobbly G-pen outlines, muted sun-bleached palette

### ChatGPT Translation
```
Cheerful early-2000s Japanese television anime aesthetic — cute, mildly super-deformed moe
character proportions with oversized rounded heads, petite bodies, narrow shoulders, slim
limbs, and tiny simplified hands, minimal noses and mouths. Enormous glossy jewel-like eyes
carry thick upper lashes, saturated blue, violet, or green irises, two crisp white highlights,
and only the simplest internal shading, with no gradient blending inside the iris. Hair forms
bold angular clumps with pointed tips, a distinctive silhouette, bright pastel color, and just
one or two flat highlight shapes, never rendered strand by strand. Drawn entirely as hand-drawn
2D television animation: dark but slightly organic outlines with natural unevenness in line
weight, uniform flat cel color fills, and a single sharply defined shadow tone — no gradients,
no soft blending, no glossy modern digital finish. Fabric folds stay sparse and graphic rather
than intricately detailed. Backgrounds are simply and softly painted with reduced detail and
gentle atmospheric color, never competing with the characters. Straightforward TV-anime framing
with strong readable silhouettes and minimal depth of field. Traditional cel animation
production quality throughout — 2D anime illustration style, no painterly texture, no 3D or
CGI rendering, no photorealistic or semi-realistic anatomy.
```

### Niji Journey Translation
```
early-2000s TV anime, mildly super-deformed moe proportions, oversized round head, glossy jewel eyes thick lashes, angular pointed hair clumps, bright pastel hair color, flat cel shading, single shadow tone, uneven hand-drawn linework, candy-pastel palette, soft simple background
--ar [ratio]
```

---

## STYLE: Alcohol Ink Wash
**Aliases:** alcohol ink wash, alcohol ink, alcohol pigment, solvent ink, fluid ink, ink bloom, ink diffusion, Yupo ink, marbled alcohol ink, fluid marbling, ink marbling
**Best for:** anime characters and scenes transformed by luminous liquid pigment — dissolving figures, fluid garments, magical effects, dreamlike environments, atmospheric transitions, and emotional key visuals where solvent-driven color movement carries the mood
**Conflicts with:** Flat Cel, hard vector art, watercolor-paper texture, visible brush application, opaque acrylic-pour cells, thick resin gloss, uniform graphic gradients, repeating geometric patterns, line art without fluid-media integration

### Visual Description
Mobile translucent pigment shaped by solvent, surface tension, displacement, evaporation,
recoil, and reactivation on a smooth, non-absorbent surface — defined by visible fluid
history, not by cells alone. Every treated passage suggests a physical event: pigment
expanding across a slick surface, one color displacing another, solvent clearing a pigment
center, liquid recoiling into a tide line, capillary branching, colliding pools forming
membranes, or dense pigment collecting along an evaporative boundary. Mixes wet translucent
pools, thin liquid membranes, irregular blooms, pale receding centers, dark evaporative tide
lines, broken scalloped drying rims, feathered capillary branches, backflow channels,
incomplete rings, sparse satellite droplets concentrated near active bloom edges, and
occasional elongated marbled ribbons — scale, density, and drying state vary throughout so
no single passage repeats. At least one focal anchor (face, eyes, hands, or central
silhouette) stays clearly resolved through value hierarchy and controlled edge transitions;
the ink must pass through the subject's or environment's own materials, never sit pasted
behind an untouched scene. No fixed palette — colors are pulled from the request and
arranged unpredictably, never rainbow order or separated bands, overlapping, recurring, and
displacing each other while staying luminous and identifiable. Metallic veining (gold,
copper, silver) is optional — a few thread-thin seams and sparse flecks at natural
intersections, never outlining every bloom.

### Flavor & Application Modes
Pick one **flavor** and one **mode** per prompt. Default to Bloom flavor and ask which mode
fits if the scene doesn't make it obvious.

**Flavors:**
- **Bloom (default)** — authentic alcohol-ink behavior: solvent-expanded blooms, translucent
  veils, pale receding centers, evaporative tide lines, broken scalloped rims, capillary
  feathering, backflow, satellite droplets. Chemically active, luminous, unpredictable.
- **Marbled hybrid** — bloom behavior stretched into elongated ribbons, folds, curling
  currents, and interrupted color bands via directional fluid marbling. Use for garments,
  sweeping environmental currents, explicitly patterned areas — motion-driven, never a
  repeating decorative pattern.

**Modes:**
- **Environmental** — sky, atmosphere, ground, water, architecture, or landscape
  progressively participates in the ink; pigment enters the actual edges, surfaces,
  reflections, and silhouettes rather than sitting behind a conventional scene. Best for
  dreamlike, elemental, apocalyptic, emotionally heightened scenes.
- **Dissolving-Figure** — hair, clothing, extremities, or outer silhouette transition into
  fluid pigment while eyes, face, hand gestures, and central anatomy stay resolved. Best for
  transformation, disappearance, memory, rebirth, otherworldly character moments.
- **Garment or Accent** — a garment, fabric, hair section, weapon, or prop carries the ink,
  following its folds, curvature, and motion. Best for fantasy fashion, portraits, card art,
  luxurious material design.
- **Magic or Effect** — ink behaves as a directional supernatural phenomenon with a clear
  source (lantern, hand, spell circle, weapon, wound); concentrated pigment expands outward
  through irregular blooms, branching, and backflow while keeping one traceable overall
  direction. Avoid centered fountains, symmetrical explosions, and radial sunbursts unless
  requested. Best for spellcasting, rituals, transformations, elemental effects.
- **Progressive-Dissolution** — the composition passes through a visible sequence from a
  fully resolved focal foreground, through minor pigment intrusion, partially interrupted
  forms, and fragmented silhouettes, to fully nonrepresentational ink at the far end —
  occurring within individual objects' own contours, not as a split between a normal lower
  scene and an unrelated abstract upper backdrop. Describe at least three visible stages.

Directional flow (Magic/Effect and Progressive-Dissolution) should read as one asymmetrical
current — S-curve, wind-bent diagonal, branching upward flow, or a plume interrupted by
backflow — never a centered fountain, rigid column, or evenly spaced radial burst.

### Style Negatives
watercolor-paper texture, fibrous paper absorption, watercolor granulation, brushed color wash, visible brushstrokes, gouache texture, oil-paint texture, opaque paint buildup, heavy concept-art surface texture, flat cel shading, hard vector outlines, smooth digital gradients, opaque acrylic-pour cells, thick resin gloss, uniform rounded bubbles, repeating cellular pattern, evenly distributed cells, ordered rainbow stripes, separate vertical color columns, evenly scattered splatter, confetti-like droplets, metallic outlines, gold around every boundary, stained-glass divisions, cloisonné effect, wallpaper-like marbling, identical edge treatment, uniformly saturated pigment, muddy gray contamination, symmetrical fountain, radial sunburst, effect pasted behind untouched architecture, melted face, blurred eyes, malformed hands

### Usage Notes
- Ask which mode fits the scene if it isn't clear from context; default to Bloom flavor
  unless the scene calls for structured currents (Marbled hybrid)
- Omit metallic veining unless the user explicitly requests it
- Never use "wash" as the primary medium label — it pulls generation toward watercolor
- When several hues are requested, explicitly prohibit rainbow ordering to keep the
  arrangement fluid and unpredictable
- For Progressive-Dissolution, name at least three concrete stages tied to real objects in
  the scene (e.g., roof tiles → eaves → hanging wires → distant architecture → sky)
- Environmental and Progressive-Dissolution modes combine well in a single prompt; the other
  three modes are best kept singular per prompt

### ChatGPT Translation

**Environmental mode:**
```
Luminous 2D anime illustration incorporating authentic translucent alcohol-ink behavior
on a smooth, non-absorbent surface. The environment transitions through slick liquid
pigment pools, thin transparent membranes, solvent-cleared centers, irregular blooms,
dark evaporative tide lines, broken scalloped rims, capillary branches, displaced-color
channels, and sparse droplets concentrated near active bloom edges.

Combine large quiet liquid fields, smaller bloom clusters, and selective negative space.
Make the transformation occur within environmental edges, surfaces, reflections, and
silhouettes rather than placing abstract ink behind an untouched scene. Preserve a
clearly resolved anime focal character with delicate variable-weight linework and
legible face and hands. [user-defined palette].

No watercolor-paper texture, watercolor granulation, visible brush application, opaque
acrylic-pour cells, thick resin gloss, uniform bubbles, repeating cell patterns, or
separate conventional and abstract zones.
```

**Dissolving-Figure mode:**
```
Luminous 2D anime character whose [hair / clothing / outer silhouette — specify]
progressively transforms into authentic translucent alcohol ink. Preserve expressive
eyes, a clearly resolved face, important hand gestures, and intact central anatomy.

At the outer edges, use slick pigment pools, thin liquid membranes, solvent-cleared
openings, broken tide lines, feathered capillary branches, backflow channels, incomplete
rings, and sparse satellite droplets. Make the transition pass visibly through the
character's materials rather than appearing as a separate ink cloud. [user-defined
palette].

No watercolor texture, visible brushstrokes, opaque paint buildup, acrylic-pour cells,
resin gloss, uniform membranes, melted face, blurred eyes, or malformed hands.
```

**Garment or Accent mode:**
```
Luminous 2D anime illustration with a clearly resolved face and hands, where
[garment / fabric / hair / object — specify] carries authentic translucent alcohol-ink
behavior. Pigment follows the object's folds, curvature, perspective, and motion through
wet translucent pools, transparent veils, displaced-color channels, irregular tide
lines, and occasional elongated liquid ribbons.

Vary scale and density. Preserve pale breathing areas and use only sparse irregular
membranes rather than an evenly repeated pattern. [user-defined palette].

No watercolor-paper texture, brushworked wash, opaque acrylic pouring, resin gloss,
wallpaper marbling, uniform rounded cells, or fluid patterns that ignore the object's
form.
```

**Magic or Effect mode:**
```
Luminous 2D anime illustration where authentic translucent alcohol ink originates
unmistakably from [source — specify]. Concentrated pigment begins at the source and moves
in an asymmetrical directional current shaped by surface tension, displacement, backflow,
branching, and changing drying states.

Use slick liquid pools, thin transparent membranes, solvent-cleared centers, evaporative
tide lines, broken scalloped rims, capillary tendrils, interrupted ribbons, and sparse
satellite droplets near active bloom edges. Integrate the effect with the character and
environment through shared movement, reflected color, lighting, and selective edge
transformation. [user-defined palette].

No watercolor texture, centered fountain, symmetrical explosion, radial sunburst,
ordered rainbow bands, excessive splatter, acrylic-pour cells, resin gloss, or effect
pasted behind untouched objects.
```

**Progressive-Dissolution mode:**
```
Luminous 2D anime illustration showing a continuous staged transformation from solid
reality into authentic translucent alcohol ink. Keep the focal foreground sharply
resolved. Give nearby forms minor pigment intrusion and feathered edges; make
middle-distance forms partially transparent and interrupted by tide lines; suspend
distant silhouettes inside liquid membranes and overlapping blooms; allow the furthest
region to become fully abstract ink.

Make the transformation occur within individual objects and along their contours.
Use wet translucent pools, solvent-cleared centers, displaced-pigment channels, broken
scalloped rims, capillary branches, backflow, changing density, and selective negative
space. [user-defined palette].

No watercolor-paper texture, brushstrokes, abrupt backdrop replacement, uniform cells,
ordered rainbow columns, opaque resin texture, metallic outlines, or loss of focal
facial and hand clarity.
```

### Niji Journey Translation

**Environmental mode:**
```
luminous 2D anime illustration, authentic translucent alcohol ink environment, smooth
non-absorbent surface, slick liquid pigment, solvent-cleared centers, evaporative tide
lines, broken scalloped rims, capillary branching, displaced-color channels, varied
wet-and-dry states, selective negative space, environment progressively dissolving
within its own edges, clearly resolved anime focal character, [user-defined palette]
--ar [ratio]
```

**Dissolving-Figure mode:**
```
luminous anime figure dissolving into authentic translucent alcohol ink, expressive
legible face and hands, outer hair and clothing becoming liquid membranes,
solvent-cleared openings, broken tide lines, capillary branches, backflow channels,
sparse satellite droplets, asymmetrical flow, delicate variable-weight anime linework,
[user-defined palette]
--ar [ratio]
```

**Garment or Accent mode:**
```
luminous anime character, resolved face and hands, authentic translucent alcohol-ink
[garment/fabric/hair], slick pigment following folds and motion, transparent liquid
veils, displaced-color channels, irregular tide lines, occasional elongated ribbons,
varied scale and negative space, [user-defined palette]
--ar [ratio]
```

**Magic or Effect mode:**
```
luminous anime character channeling authentic translucent alcohol ink from [source],
smooth non-absorbent liquid behavior, concentrated origin, asymmetrical directional
current, solvent-cleared centers, evaporative tide lines, capillary branching, backflow,
interrupted ribbons, sparse edge-clustered droplets, effect integrated through reflected
color and transformed object edges, [user-defined palette]
--ar [ratio]
```

**Progressive-Dissolution mode:**
```
luminous anime scene progressively transforming from solid foreground into authentic
translucent alcohol ink, pigment intrusion in nearby edges, partially transparent middle
distance, distant silhouettes inside liquid membranes, fully abstract ink beyond,
solvent-cleared centers, broken tide lines, capillary branches, displaced pigment,
varied wet-and-dry states, selective negative space, [user-defined palette]
--ar [ratio]
```
